from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import secrets
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .database import connect, sqlite_vec_status
from .embeddings import VECTOR_DIMENSIONS, embed_text, embed_text_result, embedding_hash, embedding_json, embedding_source_text, embedding_status
from .extractor import extract_context, now_iso, stable_id
from .vault import CortexVault


BACKEND_VERSION = "0.1.0"
HEALTH_CONTRACT = 3
BACKEND_FEATURES = (
    "local-vault",
    "capture-surfaces",
    "layered-memory",
    "trust-controls",
    "installer-updates",
    "reliability-hardening",
    "simple-product-loop",
    "operational-readiness",
)
SUPPORT_BUNDLE_SCHEMA = 1
DEFAULT_BACKUP_RETENTION_COUNT = 20
DEFAULT_BACKUP_RETENTION_DAYS = 0
DEFAULT_MCP_TOKEN_SCOPES = ("read", "write", "export", "maintenance")
MCP_TOKEN_SCOPES = {"read", "write", "export", "maintenance", "destructive"}

MEMORY_LAYERS = {"semantic", "episodic", "style", "decision", "preference", "negative"}
MEMORY_LAYER_BY_KIND = {
    "claim": "semantic",
    "observation": "semantic",
    "summary": "semantic",
    "event": "episodic",
    "decision": "decision",
    "preference": "preference",
    "style": "style",
    "negative": "negative",
}
LAYER_RETRIEVAL_BOOST = 0.02
LAYER_QUERY_INTENTS: tuple[tuple[set[str], set[str]], ...] = (
    (
        {"style", "negative"},
        {
            "copy",
            "draft",
            "language",
            "paragraph",
            "paragraphs",
            "prose",
            "style",
            "tone",
            "voice",
            "wording",
            "write",
            "writing",
        },
    ),
    (
        {"decision"},
        {
            "approach",
            "choose",
            "decide",
            "decided",
            "decision",
            "plan",
            "planning",
            "prioritize",
            "roadmap",
        },
    ),
    (
        {"preference"},
        {
            "default",
            "dislike",
            "favorite",
            "prefer",
            "preference",
            "preferred",
            "rather",
        },
    ),
    (
        {"episodic"},
        {
            "event",
            "happen",
            "happened",
            "history",
            "meeting",
            "met",
            "timeline",
            "when",
        },
    ),
)


DEFAULT_USER_SETTINGS: dict[str, Any] = {
    "review_new_captures": True,
    "allow_pending_in_context": True,
    "context_pack_limit": 12,
    "allow_agent_reads": True,
    "allow_agent_writes": False,
    "allow_agent_exports": False,
    "allow_agent_maintenance": False,
    "allow_agent_destructive_actions": False,
    "redact_sensitive_context": True,
}


SENSITIVE_PATTERNS: tuple[tuple[re.Pattern[str], str], ...] = (
    (re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"), "[REDACTED_OPENAI_KEY]"),
    (re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{20,}\b"), "[REDACTED_GITHUB_TOKEN]"),
    (re.compile(r"\b(?:xox[baprs]-[A-Za-z0-9-]{16,})\b"), "[REDACTED_SLACK_TOKEN]"),
    (
        re.compile(
            r"(?i)\b(api[_-]?key|access[_-]?token|auth[_-]?token|secret|password|passwd|pwd)\s*[:=]\s*['\"]?[^'\"\s,;]{8,}"
        ),
        r"\1=[REDACTED_SECRET]",
    ),
    (re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"), "[REDACTED_EMAIL]"),
    (re.compile(r"\b(?:\d[ -]*?){13,16}\b"), "[REDACTED_NUMBER]"),
)

SUPPORT_OMITTED_KEYS = {
    "raw_text",
    "content",
    "context_pack",
    "captures",
    "memories",
    "tasks",
    "entities",
    "edges",
}

SUPPORT_PATH_KEYS = {
    "backup_path",
    "db_path",
    "events_path",
    "index_path",
    "manifest_path",
    "path",
    "settings_path",
    "vault_path",
}


def _env_int(name: str, default: int, *, minimum: int = 0, maximum: int = 3650) -> int:
    value = os.environ.get(name)
    if value is None or value == "":
        return default
    try:
        parsed = int(value)
    except ValueError:
        return default
    return min(maximum, max(minimum, parsed))


def backup_retention_policy() -> dict[str, int]:
    return {
        "keep_latest": _env_int("CORTEX_BACKUP_RETENTION_COUNT", DEFAULT_BACKUP_RETENTION_COUNT, minimum=0, maximum=500),
        "max_age_days": _env_int("CORTEX_BACKUP_RETENTION_DAYS", DEFAULT_BACKUP_RETENTION_DAYS, minimum=0, maximum=3650),
    }


def normalize_token_scopes(scopes: list[str] | tuple[str, ...] | str | None) -> list[str]:
    if scopes is None:
        values = list(DEFAULT_MCP_TOKEN_SCOPES)
    elif isinstance(scopes, str):
        values = [item.strip().lower() for item in scopes.split(",")]
    else:
        values = [str(item).strip().lower() for item in scopes]
    return sorted({scope for scope in values if scope in MCP_TOKEN_SCOPES})


def memory_layer(kind: str | None, value: str | None = None) -> str:
    explicit = (value or "").strip().lower()
    if explicit in MEMORY_LAYERS:
        return explicit
    return MEMORY_LAYER_BY_KIND.get((kind or "").strip().lower(), "semantic")


def query_layer_boosts(query: str) -> dict[str, float]:
    tokens = set(re.findall(r"[a-z0-9_]+", query.lower()))
    boosts: dict[str, float] = {}
    for layers, keywords in LAYER_QUERY_INTENTS:
        if tokens & keywords:
            for layer in layers:
                boosts[layer] = max(boosts.get(layer, 0.0), LAYER_RETRIEVAL_BOOST)
    if "what happened" in query.lower():
        boosts["episodic"] = max(boosts.get("episodic", 0.0), LAYER_RETRIEVAL_BOOST)
    return boosts


class CortexStore:
    def __init__(self, db_path, vault_path: str | Path | None = None):
        self.db_path = Path(db_path)
        resolved_vault_path = Path(vault_path).expanduser() if vault_path else self.db_path.parent
        self.vault = CortexVault(resolved_vault_path, self.db_path)
        self.vault.ensure()

    def settings(self, user_id: str) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            return self._settings(conn, user_id)

    def ensure_vault_backfilled(self, user_id: str) -> dict[str, Any]:
        vault_diagnostics = self.vault.diagnostics()
        existing_records = sum(
            vault_diagnostics["record_counts"].get(key, 0)
            for key in ("captures", "memories", "tasks", "entities", "graph_edges")
        )
        if existing_records:
            return {"backfilled": False, "reason": "vault already has records", "records": existing_records}

        with connect(self.db_path) as conn:
            capture_rows = conn.execute("SELECT * FROM captures WHERE user_id = ? ORDER BY captured_at", (user_id,)).fetchall()
            if not capture_rows:
                self.vault.write_settings(user_id, self._settings(conn, user_id))
                return {"backfilled": False, "reason": "index has no captures", "records": 0}

            memory_rows = conn.execute("SELECT * FROM memories WHERE user_id = ? ORDER BY captured_at", (user_id,)).fetchall()
            task_rows = conn.execute("SELECT * FROM tasks WHERE user_id = ? ORDER BY captured_at", (user_id,)).fetchall()
            entity_rows = conn.execute("SELECT * FROM entities WHERE user_id = ? ORDER BY last_seen", (user_id,)).fetchall()
            edge_rows = conn.execute("SELECT * FROM graph_edges WHERE user_id = ? ORDER BY created_at", (user_id,)).fetchall()
            event_rows = conn.execute("SELECT * FROM memory_events WHERE user_id = ? ORDER BY created_at", (user_id,)).fetchall()
            self.vault.write_settings(user_id, self._settings(conn, user_id))

            for row in capture_rows:
                self.vault.write_capture(
                    {
                        "id": row["id"],
                        "user_id": row["user_id"],
                        "source": row["source"],
                        "source_url": row["source_url"],
                        "title": row["title"],
                        "raw_text": row["raw_text"],
                        "raw_hash": row["raw_hash"],
                        "summary": row["summary"],
                        "review_status": row["review_status"],
                        "approved_at": row["approved_at"],
                        "archived_at": row["archived_at"],
                        "captured_at": row["captured_at"],
                    }
                )
            for row in memory_rows:
                self.vault.write_memory(
                    {
                        "id": row["id"],
                        "capture_id": row["capture_id"],
                        "user_id": row["user_id"],
                        "kind": row["kind"],
                        "layer": memory_layer(row["kind"], row["layer"] if "layer" in row.keys() else None),
                        "content": row["content"],
                        "summary": row["summary"],
                        "source": row["source"],
                        "source_url": row["source_url"],
                        "confidence": row["confidence"],
                        "importance": row["importance"],
                        "status": row["status"],
                        "topics": json.loads(row["topics_json"] or "[]"),
                        "entity_ids": json.loads(row["entity_ids_json"] or "[]"),
                        "occurred_at": row["occurred_at"],
                        "captured_at": row["captured_at"],
                        "updated_at": row["updated_at"],
                        "raw_excerpt": row["raw_excerpt"],
                    }
                )
            for row in task_rows:
                self.vault.write_task(
                    {
                        "id": row["id"],
                        "capture_id": row["capture_id"],
                        "user_id": row["user_id"],
                        "kind": row["kind"],
                        "content": row["content"],
                        "status": row["status"],
                        "importance": row["importance"],
                        "topics": json.loads(row["topics_json"] or "[]"),
                        "entity_ids": json.loads(row["entity_ids_json"] or "[]"),
                        "captured_at": row["captured_at"],
                    }
                )
            for row in entity_rows:
                self.vault.write_entity(
                    {
                        "id": row["id"],
                        "user_id": row["user_id"],
                        "kind": row["kind"],
                        "name": row["name"],
                        "aliases": json.loads(row["aliases_json"] or "[]"),
                        "context": row["context"],
                        "first_seen": row["first_seen"],
                        "last_seen": row["last_seen"],
                    }
                )
            for row in edge_rows:
                self.vault.write_edge(dict(row))
            if vault_diagnostics["event_count"] == 0:
                for row in event_rows:
                    try:
                        metadata = json.loads(row["metadata_json"] or "{}")
                    except json.JSONDecodeError:
                        metadata = {}
                    self.vault.append_event(
                        {
                            "id": row["id"],
                            "user_id": row["user_id"],
                            "object_id": row["object_id"],
                            "object_type": row["object_type"],
                            "event_type": row["event_type"],
                            "metadata": metadata,
                            "created_at": row["created_at"],
                        }
                    )
        return {
            "backfilled": True,
            "captures": len(capture_rows),
            "memories": len(memory_rows),
            "tasks": len(task_rows),
            "entities": len(entity_rows),
            "edges": len(edge_rows),
            "events": len(event_rows),
        }

    def create_mcp_token(self, user_id: str, *, label: str = "MCP integration", scopes: list[str] | tuple[str, ...] | str | None = None) -> dict[str, Any]:
        token = "cxm_" + secrets.token_urlsafe(32).replace("-", "").replace("_", "")[:43]
        metadata = self.ensure_mcp_token(user_id, token, label=label, scopes=scopes)
        return {**metadata, "token": token}

    def ensure_mcp_token(
        self,
        user_id: str,
        token: str,
        *,
        label: str = "MCP integration",
        scopes: list[str] | tuple[str, ...] | str | None = None,
        token_id: str | None = None,
    ) -> dict[str, Any]:
        normalized = token.strip()
        if not normalized:
            raise ValueError("MCP token is required")
        timestamp = now_iso()
        resolved_scopes = normalize_token_scopes(scopes)
        resolved_token_id = token_id or stable_id("tok_", f"{user_id}:mcp:{label}")
        with connect(self.db_path) as conn:
            existing = conn.execute("SELECT token_salt FROM api_tokens WHERE token_id = ?", (resolved_token_id,)).fetchone()
            if existing:
                salt = existing["token_salt"]
            else:
                salt = secrets.token_hex(16)
            token_hash = self._token_hash(normalized, salt)
            conn.execute(
                """
                INSERT OR REPLACE INTO api_tokens
                (token_id, user_id, label, audience, token_salt, token_hash, scopes_json, created_at, updated_at, last_used_at, revoked_at)
                VALUES (
                  ?,
                  ?,
                  ?,
                  'mcp',
                  ?,
                  ?,
                  ?,
                  COALESCE((SELECT created_at FROM api_tokens WHERE token_id = ?), ?),
                  ?,
                  (SELECT last_used_at FROM api_tokens WHERE token_id = ?),
                  NULL
                )
                """,
                (
                    resolved_token_id,
                    user_id,
                    label[:120],
                    salt,
                    token_hash,
                    json.dumps(resolved_scopes),
                    resolved_token_id,
                    timestamp,
                    timestamp,
                    resolved_token_id,
                ),
            )
        return {
            "token_id": resolved_token_id,
            "user_id": user_id,
            "label": label[:120],
            "audience": "mcp",
            "scopes": resolved_scopes,
            "updated_at": timestamp,
        }

    def authenticate_mcp_token(self, token: str) -> dict[str, Any] | None:
        normalized = token.strip()
        if not normalized:
            return None
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT token_id, user_id, label, audience, token_salt, token_hash, scopes_json, created_at, last_used_at
                FROM api_tokens
                WHERE audience = 'mcp' AND revoked_at IS NULL
                ORDER BY created_at DESC
                """
            ).fetchall()
            for row in rows:
                candidate = self._token_hash(normalized, row["token_salt"])
                if not secrets.compare_digest(candidate, row["token_hash"]):
                    continue
                conn.execute("UPDATE api_tokens SET last_used_at = ? WHERE token_id = ?", (timestamp, row["token_id"]))
                return {
                    "token_id": row["token_id"],
                    "user_id": row["user_id"],
                    "label": row["label"],
                    "audience": row["audience"],
                    "scopes": self._json_list(row["scopes_json"]),
                    "created_at": row["created_at"],
                    "last_used_at": timestamp,
                    "admin": False,
                }
        return None

    def enqueue_capture(
        self,
        *,
        user_id: str,
        content: str,
        source: str,
        source_url: str | None,
        title: str | None,
    ) -> dict[str, Any]:
        content = content.strip()
        if not content:
            raise ValueError("content is required")
        if len(content) > 200_000:
            raise ValueError("content is too large")
        captured_at = now_iso()
        normalized_source = (source or "macos")[:80]
        capture_id = stable_id("cap_", user_id + normalized_source + captured_at + content[:120])
        raw_hash = stable_id("", content)
        summary = "Queued for memory extraction."
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            review_status = "pending" if user_settings["review_new_captures"] else "approved"
            approved_at = None if review_status == "pending" else captured_at
            conn.execute(
                """
                INSERT OR REPLACE INTO captures
                (id, user_id, source, source_url, title, raw_text, raw_hash, summary, review_status, approved_at, captured_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (capture_id, user_id, normalized_source, source_url, title, content, raw_hash, summary, review_status, approved_at, captured_at),
            )
            job = self._enqueue_job(
                conn,
                user_id=user_id,
                job_type="extract_capture",
                object_type="capture",
                object_id=capture_id,
                unique_key=f"extract_capture:{capture_id}:{raw_hash}",
                payload={
                    "capture_id": capture_id,
                    "source": normalized_source,
                    "source_url": source_url,
                    "title": title,
                    "captured_at": captured_at,
                    "raw_hash": raw_hash,
                },
                priority=50,
            )
            conn.execute(
                """
                INSERT OR REPLACE INTO capture_processing_state
                (capture_id, user_id, ingest_status, extraction_status, embedding_status, memory_count, task_count, entity_count, last_job_id, last_error, queued_at, updated_at)
                VALUES (?, ?, 'accepted', 'queued', 'pending', 0, 0, 0, ?, NULL, ?, ?)
                """,
                (capture_id, user_id, job["id"], captured_at, captured_at),
            )
            self._event(conn, user_id, capture_id, "capture", "queued", {"source": normalized_source, "job_id": job["id"]})
            self.vault.write_settings(user_id, user_settings)
            self.vault.write_capture(
                {
                    "id": capture_id,
                    "user_id": user_id,
                    "source": normalized_source,
                    "source_url": source_url,
                    "title": title,
                    "raw_text": content,
                    "raw_hash": raw_hash,
                    "summary": summary,
                    "review_status": review_status,
                    "approved_at": approved_at,
                    "archived_at": None,
                    "captured_at": captured_at,
                    "processing": {"ingest_status": "accepted", "extraction_status": "queued", "job_id": job["id"]},
                }
            )
        return {
            "capture_id": capture_id,
            "status": "queued",
            "summary": summary,
            "jobs": [job],
            "processing": self.capture_status(user_id, capture_id),
        }

    def capture_status(self, user_id: str, capture_id: str) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            capture = conn.execute(
                "SELECT id, source, title, review_status, captured_at FROM captures WHERE user_id = ? AND id = ?",
                (user_id, capture_id),
            ).fetchone()
            if not capture:
                raise FileNotFoundError("Capture not found")
            state = conn.execute(
                "SELECT * FROM capture_processing_state WHERE user_id = ? AND capture_id = ?",
                (user_id, capture_id),
            ).fetchone()
            jobs = conn.execute(
                """
                SELECT *
                FROM memory_jobs
                WHERE user_id = ?
                  AND (
                    (object_type = 'capture' AND object_id = ?)
                    OR (
                      object_type = 'memory'
                      AND object_id IN (
                        SELECT id FROM memories WHERE user_id = ? AND capture_id = ?
                      )
                    )
                  )
                ORDER BY created_at DESC
                """,
                (user_id, capture_id, user_id, capture_id),
            ).fetchall()
        state_payload = dict(state) if state else {
            "capture_id": capture_id,
            "user_id": user_id,
            "ingest_status": "materialized",
            "extraction_status": "succeeded",
            "embedding_status": "available",
            "memory_count": None,
            "task_count": None,
            "entity_count": None,
            "last_job_id": None,
            "last_error": None,
            "queued_at": capture["captured_at"],
            "started_at": None,
            "completed_at": capture["captured_at"],
            "updated_at": capture["captured_at"],
        }
        return {
            "capture": dict(capture),
            "processing": state_payload,
            "jobs": [self._job_from_row(row) for row in jobs],
        }

    def get_job(self, user_id: str, job_id: str) -> dict[str, Any] | None:
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT * FROM memory_jobs WHERE user_id = ? AND id = ?", (user_id, job_id)).fetchone()
        return self._job_from_row(row) if row else None

    def list_jobs(self, user_id: str, *, status: str | None = None, job_type: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        filters = ["user_id = ?"]
        params: list[Any] = [user_id]
        if status:
            filters.append("status = ?")
            params.append(status)
        if job_type:
            filters.append("job_type = ?")
            params.append(job_type)
        with connect(self.db_path) as conn:
            rows = conn.execute(
                f"""
                SELECT *
                FROM memory_jobs
                WHERE {' AND '.join(filters)}
                ORDER BY
                  CASE status WHEN 'failed' THEN 0 WHEN 'running' THEN 1 WHEN 'queued' THEN 2 ELSE 3 END,
                  updated_at DESC
                LIMIT ?
                """,
                [*params, limit],
            ).fetchall()
        return [self._job_from_row(row) for row in rows]

    def run_due_jobs(self, user_id: str, *, limit: int = 10, worker_id: str = "local-worker") -> dict[str, Any]:
        processed: list[dict[str, Any]] = []
        for _ in range(max(0, min(limit, 100))):
            job = self._claim_next_job(user_id, worker_id)
            if not job:
                break
            processed.append(self._run_job(job, worker_id))
        return {
            "ran_at": now_iso(),
            "processed": len(processed),
            "jobs": processed,
            "pending": len(self.list_jobs(user_id, status="queued", limit=100)),
            "failed": len(self.list_jobs(user_id, status="failed", limit=100)),
        }

    def update_settings(self, user_id: str, updates: dict[str, Any]) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            current = self._settings(conn, user_id)
            merged = {**current}
            if "review_new_captures" in updates:
                merged["review_new_captures"] = bool(updates["review_new_captures"])
            if "allow_pending_in_context" in updates:
                merged["allow_pending_in_context"] = bool(updates["allow_pending_in_context"])
            if "context_pack_limit" in updates:
                try:
                    value = int(updates["context_pack_limit"])
                except (TypeError, ValueError):
                    value = int(DEFAULT_USER_SETTINGS["context_pack_limit"])
                merged["context_pack_limit"] = min(50, max(4, value))
            for key in (
                "allow_agent_reads",
                "allow_agent_writes",
                "allow_agent_exports",
                "allow_agent_maintenance",
                "allow_agent_destructive_actions",
                "redact_sensitive_context",
            ):
                if key in updates:
                    merged[key] = bool(updates[key])
            timestamp = now_iso()
            for key, value in merged.items():
                conn.execute(
                    """
                    INSERT OR REPLACE INTO user_settings(user_id, key, value_json, updated_at)
                    VALUES (?, ?, ?, ?)
                    """,
                    (user_id, key, json.dumps(value), timestamp),
                )
            self._event(conn, user_id, user_id, "settings", "updated", merged)
            self.vault.write_settings(user_id, merged)
            return merged

    def save_capture(
        self,
        *,
        user_id: str,
        content: str,
        source: str,
        source_url: str | None,
        title: str | None,
        extracted: dict[str, Any],
    ) -> dict[str, Any]:
        captured_at = extracted.get("_timestamp") or now_iso()
        capture_id = stable_id("cap_", user_id + source + captured_at + content[:120])
        raw_hash = stable_id("", content)
        summary = extracted.get("summary", "")
        user_settings_snapshot: dict[str, Any] = {}
        review_status = "pending"
        approved_at = None
        memories: list[dict[str, Any]] = []
        tasks: list[dict[str, Any]] = []
        entities: list[dict[str, Any]] = []
        edges: list[dict[str, Any]] = []

        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            user_settings_snapshot = dict(user_settings)
            review_status = "pending" if user_settings["review_new_captures"] else "approved"
            approved_at = None if review_status == "pending" else captured_at
            conn.execute(
                """
                INSERT OR REPLACE INTO captures
                (id, user_id, source, source_url, title, raw_text, raw_hash, summary, review_status, approved_at, captured_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (capture_id, user_id, source, source_url, title, content, raw_hash, summary, review_status, approved_at, captured_at),
            )
            self._event(conn, user_id, capture_id, "capture", "created", {"source": source, "title": title})

            for record in extracted.get("records", []):
                memory = self._save_memory(conn, capture_id, user_id, record, source, source_url, captured_at, content)
                memories.append(memory)
                edges.append(self._edge(conn, user_id, capture_id, memory["id"], "contains", memory["id"], captured_at))

            for task in extracted.get("tasks", []):
                saved_task = self._save_task(conn, capture_id, user_id, task, captured_at)
                tasks.append(saved_task)
                edges.append(self._edge(conn, user_id, capture_id, saved_task["id"], "creates_task", saved_task["id"], captured_at))

            for entity in extracted.get("entities", []):
                entities.append(self._save_entity(conn, user_id, entity, captured_at))

            for memory in memories:
                for entity_id in memory.get("entity_ids", []):
                    edges.append(self._edge(conn, user_id, memory["id"], entity_id, "mentions", memory["id"], captured_at))

            for task in tasks:
                for entity_id in task.get("entity_ids", []):
                    edges.append(self._edge(conn, user_id, task["id"], entity_id, "involves", task["id"], captured_at))

            entity_ids = [entity["id"] for entity in entities]
            for index, left in enumerate(entity_ids):
                for right in entity_ids[index + 1:]:
                    edges.append(self._edge(conn, user_id, left, right, "co_occurs", capture_id, captured_at, weight=0.5))

            embedding_state = self._capture_embedding_status(conn, user_id, capture_id)
            conn.execute(
                """
                INSERT OR IGNORE INTO capture_processing_state
                (capture_id, user_id, ingest_status, extraction_status, embedding_status, memory_count, task_count, entity_count, last_job_id, last_error, queued_at, started_at, completed_at, updated_at)
                VALUES (?, ?, 'materialized', 'succeeded', ?, ?, ?, ?, NULL, NULL, ?, ?, ?, ?)
                """,
                (
                    capture_id,
                    user_id,
                    embedding_state,
                    len(memories),
                    len(tasks),
                    len(entities),
                    captured_at,
                    captured_at,
                    captured_at,
                    captured_at,
                ),
            )

            self.vault.write_settings(user_id, user_settings_snapshot)
            self.vault.write_capture_bundle(
                capture={
                    "id": capture_id,
                    "user_id": user_id,
                    "source": source,
                    "source_url": source_url,
                    "title": title,
                    "raw_text": content,
                    "raw_hash": raw_hash,
                    "summary": summary,
                    "review_status": review_status,
                    "approved_at": approved_at,
                    "archived_at": None,
                    "captured_at": captured_at,
                },
                memories=memories,
                tasks=tasks,
                entities=entities,
                edges=edges,
            )

        return {
            "capture_id": capture_id,
            "summary": summary,
            "memories": memories,
            "tasks": tasks,
            "entities": entities,
            "graph": {"nodes": self.graph(user_id, limit=80)["nodes"], "edges": edges},
        }

    def inbox(self, user_id: str, limit: int = 30) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT
                  c.*,
                  COUNT(DISTINCT m.id) AS memory_count,
                  COUNT(DISTINCT t.id) AS task_count
                FROM captures c
                LEFT JOIN memories m ON m.capture_id = c.id AND m.status = 'active'
                LEFT JOIN tasks t ON t.capture_id = c.id AND t.status = 'open'
                WHERE c.user_id = ? AND c.review_status = 'pending'
                GROUP BY c.id
                ORDER BY c.captured_at DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        return [self._capture_from_row(row) for row in rows]

    def recent(self, user_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            filters, params = self._memory_filters(user_id, user_settings, alias="m")
            where = " AND ".join(filters)
            rows = conn.execute(
                f"SELECT * FROM memories m WHERE {where} ORDER BY m.captured_at DESC LIMIT ?",
                [*params, limit],
            ).fetchall()
        return [self._memory_from_row(row) for row in rows]

    def search(self, user_id: str, query: str, limit: int = 10, kind: str | None = None, layer: str | None = None) -> list[dict[str, Any]]:
        query = query.strip()
        if not query:
            return self.recent(user_id, limit)

        fts_query = self._fts_query(query)
        candidate_limit = max(limit * 4, 12)

        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            filters, params = self._memory_filters(user_id, user_settings, alias="m", kind=kind, layer=layer)
            where = " AND ".join(filters)
            rows = []
            fts_rows = []
            if fts_query:
                fts_rows = conn.execute(
                    f"""
                    SELECT m.*, bm25(memory_fts) AS rank
                    FROM memory_fts
                    JOIN memories m ON m.id = memory_fts.memory_id
                    WHERE memory_fts MATCH ? AND {where}
                    ORDER BY rank ASC, m.importance DESC, m.captured_at DESC
                    LIMIT ?
                    """,
                    [fts_query, *params, candidate_limit],
                ).fetchall()
            vector_rows = self._vector_search(conn, user_id, query, candidate_limit, kind, layer, user_settings)
            rows = self._fuse_search_rows(query, fts_rows, vector_rows, limit)
            if not rows:
                like = f"%{query}%"
                fallback_rows = conn.execute(
                    f"""
                    SELECT * FROM memories m
                    WHERE {where} AND (m.content LIKE ? OR m.summary LIKE ? OR m.source LIKE ?)
                    ORDER BY m.importance DESC, m.captured_at DESC
                    LIMIT ?
                    """,
                    [*params, like, like, like, candidate_limit],
                ).fetchall()
                rows = self._rank_rows_with_layer_boosts(query, fallback_rows, limit)
        return [self._memory_from_row(row) for row in rows]

    def open_tasks(self, user_id: str, limit: int = 20) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            filters = ["t.user_id = ?", "t.status = 'open'"]
            params: list[Any] = [user_id]
            if not user_settings["allow_pending_in_context"]:
                filters.append(
                    "(t.capture_id IS NULL OR EXISTS (SELECT 1 FROM captures c WHERE c.id = t.capture_id AND c.user_id = t.user_id AND c.review_status = 'approved'))"
                )
            where = " AND ".join(filters)
            rows = conn.execute(
                f"SELECT * FROM tasks t WHERE {where} ORDER BY t.importance DESC, t.captured_at DESC LIMIT ?",
                [*params, limit],
            ).fetchall()
        return [self._task_from_row(row) for row in rows]

    def list_topics(self, user_id: str, limit: int = 30) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            review_filter = ""
            if not user_settings["allow_pending_in_context"]:
                review_filter = "AND (m.capture_id IS NULL OR EXISTS (SELECT 1 FROM captures c WHERE c.id = m.capture_id AND c.user_id = m.user_id AND c.review_status = 'approved'))"
            rows = conn.execute(
                f"""
                SELECT mt.topic, COUNT(*) AS count, MAX(m.captured_at) AS last_seen
                FROM memory_topics mt
                JOIN memories m ON m.id = mt.memory_id AND m.user_id = mt.user_id
                WHERE mt.user_id = ? AND m.status = 'active'
                  {review_filter}
                GROUP BY mt.topic
                ORDER BY count DESC, last_seen DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def list_entities(self, user_id: str, limit: int = 30) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            review_join_filter = ""
            if not user_settings["allow_pending_in_context"]:
                review_join_filter = "AND (m.capture_id IS NULL OR EXISTS (SELECT 1 FROM captures c WHERE c.id = m.capture_id AND c.user_id = m.user_id AND c.review_status = 'approved'))"
            rows = conn.execute(
                f"""
                SELECT e.id, e.name, e.kind, e.context, e.first_seen, e.last_seen, COUNT(m.id) AS memory_count
                FROM entities e
                LEFT JOIN memory_entities me ON me.entity_id = e.id AND me.user_id = e.user_id
                LEFT JOIN memories m ON m.id = me.memory_id AND m.user_id = me.user_id AND m.status = 'active' {review_join_filter}
                WHERE e.user_id = ?
                GROUP BY e.id
                HAVING memory_count > 0
                ORDER BY memory_count DESC, e.last_seen DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def about_person(self, user_id: str, name: str, limit: int = 12) -> list[dict[str, Any]]:
        slug = "person_" + "".join(ch.lower() if ch.isalnum() else "-" for ch in name).strip("-")
        results = self.search(user_id, name, limit=limit)
        return [item for item in results if slug in item.get("entity_ids", []) or name.lower() in item.get("content", "").lower()]

    def about_entity(self, user_id: str, name: str, limit: int = 12) -> list[dict[str, Any]]:
        slug = "".join(ch.lower() if ch.isalnum() else "-" for ch in name).strip("-")
        entity_suffix = "_" + slug
        results = self.search(user_id, name, limit=limit)
        return [
            item
            for item in results
            if any(entity_id.endswith(entity_suffix) for entity_id in item.get("entity_ids", []))
            or name.lower() in item.get("content", "").lower()
        ]

    def archive_memory(self, user_id: str, memory_id: str) -> bool:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT id FROM memories WHERE user_id = ? AND id = ?", (user_id, memory_id)).fetchone()
            if not row:
                return False
            conn.execute("UPDATE memories SET status = 'archived', updated_at = ? WHERE user_id = ? AND id = ?", (timestamp, user_id, memory_id))
            conn.execute("DELETE FROM memory_fts WHERE memory_id = ?", (memory_id,))
            self._delete_memory_vector(conn, memory_id)
            conn.execute(
                "DELETE FROM memory_jobs WHERE user_id = ? AND object_type = 'memory' AND object_id = ?",
                (user_id, memory_id),
            )
            self._event(conn, user_id, memory_id, "memory", "archived", {})
            self.vault.patch_memory(memory_id, {"status": "archived", "updated_at": timestamp})
        return True

    def delete_memory(self, user_id: str, memory_id: str) -> bool:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT id FROM memories WHERE user_id = ? AND id = ?", (user_id, memory_id)).fetchone()
            if not row:
                return False
            edge_ids = self._purge_edges_for_objects(conn, user_id, [memory_id])
            self._purge_memory_rows(conn, user_id, [memory_id])
            self._event(conn, user_id, memory_id, "memory", "deleted", {"hard_delete": True, "edge_count": len(edge_ids)})
            self.vault.delete_memory(memory_id)
            for edge_id in edge_ids:
                self.vault.delete_edge(edge_id)
            self.vault.write_tombstone(
                user_id=user_id,
                object_type="memory",
                object_id=memory_id,
                deleted_at=timestamp,
                reason="memory_deleted",
                related_ids=edge_ids,
                metadata={"edge_count": len(edge_ids)},
            )
        return True

    def delete_capture(self, user_id: str, capture_id: str) -> bool:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT id FROM captures WHERE user_id = ? AND id = ?", (user_id, capture_id)).fetchone()
            if not row:
                return False
            memory_ids = [
                row["id"]
                for row in conn.execute("SELECT id FROM memories WHERE user_id = ? AND capture_id = ?", (user_id, capture_id)).fetchall()
            ]
            task_ids = [
                row["id"]
                for row in conn.execute("SELECT id FROM tasks WHERE user_id = ? AND capture_id = ?", (user_id, capture_id)).fetchall()
            ]
            edge_ids = self._purge_edges_for_objects(conn, user_id, [capture_id, *memory_ids, *task_ids])
            self._purge_memory_rows(conn, user_id, memory_ids)
            self._purge_task_rows(conn, user_id, task_ids)
            conn.execute(
                "DELETE FROM memory_jobs WHERE user_id = ? AND object_type = 'capture' AND object_id = ?",
                (user_id, capture_id),
            )
            conn.execute("DELETE FROM captures WHERE user_id = ? AND id = ?", (user_id, capture_id))
            self._event(
                conn,
                user_id,
                capture_id,
                "capture",
                "deleted",
                {"hard_delete": True, "memory_count": len(memory_ids), "task_count": len(task_ids), "edge_count": len(edge_ids)},
            )
            self.vault.delete_capture(capture_id)
            for memory_id in memory_ids:
                self.vault.delete_memory(memory_id)
            for task_id in task_ids:
                self.vault.delete_task(task_id)
            for edge_id in edge_ids:
                self.vault.delete_edge(edge_id)
            self.vault.write_tombstone(
                user_id=user_id,
                object_type="capture",
                object_id=capture_id,
                deleted_at=timestamp,
                reason="capture_deleted",
                related_ids=[*memory_ids, *task_ids, *edge_ids],
                metadata={"memory_count": len(memory_ids), "task_count": len(task_ids), "edge_count": len(edge_ids)},
            )
        return True

    def approve_capture(self, user_id: str, capture_id: str) -> bool:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT id FROM captures WHERE user_id = ? AND id = ?", (user_id, capture_id)).fetchone()
            if not row:
                return False
            conn.execute(
                "UPDATE captures SET review_status = 'approved', approved_at = ?, archived_at = NULL WHERE user_id = ? AND id = ?",
                (timestamp, user_id, capture_id),
            )
            self._event(conn, user_id, capture_id, "capture", "approved", {})
            self.vault.patch_capture(capture_id, {"review_status": "approved", "approved_at": timestamp, "archived_at": None})
        return True

    def archive_capture(self, user_id: str, capture_id: str) -> bool:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute("SELECT id FROM captures WHERE user_id = ? AND id = ?", (user_id, capture_id)).fetchone()
            if not row:
                return False
            conn.execute(
                "UPDATE captures SET review_status = 'archived', archived_at = ? WHERE user_id = ? AND id = ?",
                (timestamp, user_id, capture_id),
            )
            memory_ids = [
                row["id"]
                for row in conn.execute("SELECT id FROM memories WHERE user_id = ? AND capture_id = ?", (user_id, capture_id)).fetchall()
            ]
            task_ids = [
                row["id"]
                for row in conn.execute("SELECT id FROM tasks WHERE user_id = ? AND capture_id = ?", (user_id, capture_id)).fetchall()
            ]
            conn.execute("UPDATE memories SET status = 'archived', updated_at = ? WHERE user_id = ? AND capture_id = ?", (timestamp, user_id, capture_id))
            conn.execute("UPDATE tasks SET status = 'archived' WHERE user_id = ? AND capture_id = ?", (user_id, capture_id))
            for memory_id in memory_ids:
                conn.execute("DELETE FROM memory_fts WHERE memory_id = ?", (memory_id,))
                self._delete_memory_vector(conn, memory_id)
            self._event(conn, user_id, capture_id, "capture", "archived", {"memory_count": len(memory_ids)})
            self.vault.patch_capture(capture_id, {"review_status": "archived", "archived_at": timestamp})
            for memory_id in memory_ids:
                self.vault.patch_memory(memory_id, {"status": "archived", "updated_at": timestamp})
            for task_id in task_ids:
                self.vault.patch_task(task_id, {"status": "archived"})
        return True

    def stats(self, user_id: str) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            counts = {
                "captures": conn.execute("SELECT COUNT(*) FROM captures WHERE user_id = ?", (user_id,)).fetchone()[0],
                "pending_captures": conn.execute("SELECT COUNT(*) FROM captures WHERE user_id = ? AND review_status = 'pending'", (user_id,)).fetchone()[0],
                "memories": conn.execute("SELECT COUNT(*) FROM memories WHERE user_id = ? AND status = 'active'", (user_id,)).fetchone()[0],
                "decisions": conn.execute("SELECT COUNT(*) FROM memories WHERE user_id = ? AND status = 'active' AND kind = 'decision'", (user_id,)).fetchone()[0],
                "tasks": conn.execute("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'open'", (user_id,)).fetchone()[0],
                "entities": conn.execute("SELECT COUNT(*) FROM entities WHERE user_id = ?", (user_id,)).fetchone()[0],
                "edges": conn.execute(
                    """
                    SELECT COUNT(*)
                    FROM graph_edges ge
                    LEFT JOIN captures c ON c.id = ge.evidence_id AND c.user_id = ge.user_id
                    LEFT JOIN memories m ON m.id = ge.evidence_id AND m.user_id = ge.user_id
                    LEFT JOIN tasks t ON t.id = ge.evidence_id AND t.user_id = ge.user_id
                    WHERE ge.user_id = ?
                      AND (
                        ge.evidence_id IS NULL
                        OR c.review_status IN ('pending', 'approved')
                        OR m.status = 'active'
                        OR t.status = 'open'
                      )
                    """,
                    (user_id,),
                ).fetchone()[0],
            }
            by_kind = [
                {"kind": row["kind"], "count": row["count"]}
                for row in conn.execute(
                    "SELECT kind, COUNT(*) AS count FROM memories WHERE user_id = ? AND status = 'active' GROUP BY kind ORDER BY count DESC",
                    (user_id,),
                ).fetchall()
            ]
            by_layer = [
                {"layer": row["layer"], "count": row["count"]}
                for row in conn.execute(
                    "SELECT layer, COUNT(*) AS count FROM memories WHERE user_id = ? AND status = 'active' GROUP BY layer ORDER BY count DESC",
                    (user_id,),
                ).fetchall()
            ]
            top_topics = [
                {"topic": row["topic"], "count": row["count"]}
                for row in conn.execute(
                    """
                    SELECT mt.topic, COUNT(*) AS count
                    FROM memory_topics mt
                    JOIN memories m ON m.id = mt.memory_id AND m.user_id = mt.user_id
                    WHERE mt.user_id = ? AND m.status = 'active'
                    GROUP BY mt.topic
                    ORDER BY count DESC, mt.topic
                    LIMIT 12
                    """,
                    (user_id,),
                ).fetchall()
            ]
            top_entities = [
                {"id": row["id"], "name": row["name"], "kind": row["kind"], "count": row["count"]}
                for row in conn.execute(
                    """
                    SELECT e.id, e.name, e.kind, COUNT(m.id) AS count
                    FROM entities e
                    JOIN memory_entities me ON me.entity_id = e.id AND me.user_id = e.user_id
                    JOIN memories m ON m.id = me.memory_id AND m.user_id = me.user_id AND m.status = 'active'
                    WHERE e.user_id = ?
                    GROUP BY e.id
                    ORDER BY count DESC, e.last_seen DESC
                    LIMIT 12
                    """,
                    (user_id,),
                ).fetchall()
            ]
        return {**counts, "by_kind": by_kind, "by_layer": by_layer, "top_topics": top_topics, "top_entities": top_entities}

    def product_loop(self, user_id: str) -> dict[str, Any]:
        stats = self.stats(user_id)
        with connect(self.db_path) as conn:
            captured_today = conn.execute(
                "SELECT COUNT(*) FROM captures WHERE user_id = ? AND substr(captured_at, 1, 10) = date('now')",
                (user_id,),
            ).fetchone()[0]
            approved_today = conn.execute(
                "SELECT COUNT(*) FROM captures WHERE user_id = ? AND approved_at IS NOT NULL AND substr(approved_at, 1, 10) = date('now')",
                (user_id,),
            ).fetchone()[0]
            reused_today = conn.execute(
                """
                SELECT COUNT(*)
                FROM memory_events
                WHERE user_id = ?
                  AND object_type = 'loop'
                  AND event_type = 'context_reused'
                  AND substr(created_at, 1, 10) = date('now')
                """,
                (user_id,),
            ).fetchone()[0]
            last_reused_at = conn.execute(
                """
                SELECT MAX(created_at)
                FROM memory_events
                WHERE user_id = ?
                  AND object_type = 'loop'
                  AND event_type = 'context_reused'
                """,
                (user_id,),
            ).fetchone()[0]
            active_days = [
                row["day"]
                for row in conn.execute(
                    """
                    SELECT day
                    FROM (
                      SELECT substr(captured_at, 1, 10) AS day
                      FROM captures
                      WHERE user_id = ? AND captured_at >= datetime('now', '-30 days')
                      UNION
                      SELECT substr(created_at, 1, 10) AS day
                      FROM memory_events
                      WHERE user_id = ?
                        AND object_type = 'loop'
                        AND event_type = 'context_reused'
                        AND created_at >= datetime('now', '-30 days')
                    )
                    GROUP BY day
                    ORDER BY day DESC
                    """,
                    (user_id, user_id),
                ).fetchall()
            ]
            today = conn.execute("SELECT date('now')").fetchone()[0]

        active_day_set = set(active_days)
        streak_days = 0
        with connect(self.db_path) as conn:
            streak_rows = conn.execute(
                """
                WITH RECURSIVE days(offset, day) AS (
                  SELECT 0, date('now')
                  UNION ALL
                  SELECT offset + 1, date('now', '-' || (offset + 1) || ' days')
                  FROM days
                  WHERE offset < 29
                )
                SELECT day FROM days
                """,
            ).fetchall()
        for row in streak_rows:
            if row["day"] in active_day_set:
                streak_days += 1
            else:
                break

        capture_done = stats["captures"] > 0
        review_done = stats["captures"] > 0 and stats["pending_captures"] == 0
        reuse_done = reused_today > 0
        return_done = streak_days >= 2

        if not capture_done:
            primary = {
                "action": "capture",
                "label": "Add First Source",
                "title": "Start your personal model",
                "detail": "Add a decision, preference, writing sample, project detail, or open loop.",
            }
        elif stats["pending_captures"] > 0:
            primary = {
                "action": "review",
                "label": "Review Inbox",
                "title": "Review new signals",
                "detail": f"{stats['pending_captures']} capture{'s' if stats['pending_captures'] != 1 else ''} need approval before they strengthen the model.",
            }
        elif not reuse_done:
            primary = {
                "action": "reuse",
                "label": "Ask Cortex",
                "title": "Use your personal model",
                "detail": "Use Cortex memory in your next AI session and check model coverage afterward.",
            }
        else:
            primary = {
                "action": "done",
                "label": "Loop Complete",
                "title": "Loop complete today",
                "detail": "You added or reviewed signals and used approved memory. Keep Cortex nearby as work changes.",
            }

        def step(key: str, title: str, done: bool, detail: str) -> dict[str, Any]:
            status = "done" if done else "current" if primary["action"] == key else "waiting"
            return {"key": key, "title": title, "status": status, "detail": detail}

        steps = [
            step("capture", "Signal", capture_done, f"{captured_today} added today, {stats['captures']} total."),
            step("review", "Review", review_done, f"{stats['pending_captures']} waiting in the inbox."),
            step("reuse", "Access", reuse_done, f"{reused_today} approved memory handoff{'s' if reused_today != 1 else ''} prepared today."),
            step("done", "Return", return_done, f"{streak_days} day streak."),
        ]
        completion = round((sum(1 for item in steps if item["status"] == "done") / len(steps)) * 100)

        return {
            "generated_at": now_iso(),
            "status": "complete" if primary["action"] == "done" else "active",
            "completion": completion,
            "primary_action": primary,
            "steps": steps,
            "counts": {
                "captures_today": captured_today,
                "approved_today": approved_today,
                "pending_captures": stats["pending_captures"],
                "reused_today": reused_today,
                "active_days_30d": len(active_day_set),
                "streak_days": streak_days,
            },
            "last_reused_at": last_reused_at,
            "today": today,
        }

    def record_context_reuse(self, user_id: str, *, surface: str, query: str = "", target: str = "") -> dict[str, Any]:
        metadata = {
            "surface": (surface or "unknown")[:80],
            "query": (query or "")[:160],
            "target": (target or "")[:80],
        }
        with connect(self.db_path) as conn:
            event = self._event(conn, user_id, "context_pack", "loop", "context_reused", metadata)
        return {"recorded": True, "event": event, "product_loop": self.product_loop(user_id)}

    def daily_review(self, user_id: str) -> dict[str, Any]:
        stats = self.stats(user_id)
        pending = self.inbox(user_id, limit=6)
        recent_memories = self.recent(user_id, limit=8)
        open_tasks = self.open_tasks(user_id, limit=8)
        recent_decisions = self._memories_by_kind(user_id, "decision", limit=6)
        top_topics = self.list_topics(user_id, limit=8)
        top_entities = self.list_entities(user_id, limit=8)
        with connect(self.db_path) as conn:
            activity = [
                dict(row)
                for row in conn.execute(
                    """
                    SELECT substr(captured_at, 1, 10) AS day, COUNT(*) AS captures
                    FROM captures
                    WHERE user_id = ? AND substr(captured_at, 1, 10) >= date('now', '-6 days')
                    GROUP BY day
                    ORDER BY day DESC
                    """,
                    (user_id,),
                ).fetchall()
            ]
            captured_today = conn.execute(
                "SELECT COUNT(*) FROM captures WHERE user_id = ? AND substr(captured_at, 1, 10) = date('now')",
                (user_id,),
            ).fetchone()[0]
            approved_today = conn.execute(
                "SELECT COUNT(*) FROM captures WHERE user_id = ? AND approved_at IS NOT NULL AND substr(approved_at, 1, 10) = date('now')",
                (user_id,),
            ).fetchone()[0]
        recommended_actions = self._recommended_actions(
            pending_count=stats["pending_captures"],
            open_task_count=stats["tasks"],
            captured_today=captured_today,
            top_topics=top_topics,
            recent_decisions=recent_decisions,
        )
        momentum_score = min(
            100,
            max(
                0,
                captured_today * 12
                + approved_today * 8
                + len(recent_decisions) * 5
                + min(stats["memories"], 20)
                - min(stats["pending_captures"], 10) * 3,
            ),
        )
        focus_query = " ".join(item["topic"] for item in top_topics[:3]) or ""
        return {
            "generated_at": now_iso(),
            "momentum_score": momentum_score,
            "captured_today": captured_today,
            "approved_today": approved_today,
            "stats": stats,
            "pending": pending,
            "recent_memories": recent_memories,
            "recent_decisions": recent_decisions,
            "open_tasks": open_tasks,
            "top_topics": top_topics,
            "top_entities": top_entities,
            "capture_activity": activity,
            "recommended_actions": recommended_actions,
            "context_pack": self.context_pack(user_id, query=focus_query, limit=8),
            "product_loop": self.product_loop(user_id),
        }

    def context_pack(self, user_id: str, query: str = "", limit: int | None = None) -> str:
        query = query.strip()
        user_settings = self.settings(user_id)
        if limit is None:
            limit = int(user_settings["context_pack_limit"])
        memories = self.search(user_id, query, limit=limit) if query else self.recent(user_id, limit=limit)
        decisions = self._memories_by_kind(user_id, "decision", limit=5)
        tasks = self.open_tasks(user_id, limit=8)
        topics = self.list_topics(user_id, limit=8)
        entities = self.list_entities(user_id, limit=8)
        redact = bool(user_settings["redact_sensitive_context"])

        lines = [
            "# Cortex Memory View",
            "",
            f"Generated: {now_iso()}",
        ]
        if query:
            lines.append(f"Focus: {query}")
        lines.extend([
            "",
            "Use this Cortex context as partial, cited memory for this conversation. Treat it as coverage-limited, follow the user's newest message when there is conflict, and ask when coverage is missing.",
            "",
            "## Suggested Assistant Instruction",
            "",
            "Use the Cortex context below as scoped memory for this conversation. When a memory is relevant, ground the answer in it and mention the memory ID if useful. If the context conflicts with the user's newest message, follow the newest message and note the mismatch.",
            "",
            "## Relevant Memories",
            "",
        ])
        if memories:
            layer_titles = {
                "decision": "Decision Memory",
                "preference": "Preference Memory",
                "style": "Style Memory",
                "negative": "Negative Memory",
                "episodic": "Episodic Memory",
                "semantic": "Semantic Memory",
            }
            layer_order = ["decision", "preference", "style", "negative", "episodic", "semantic"]
            for layer in layer_order:
                grouped = [item for item in memories if memory_layer(item.get("kind"), item.get("layer")) == layer]
                if not grouped:
                    continue
                lines.extend([f"### {layer_titles[layer]}", ""])
                for item in grouped:
                    date = item.get("captured_at") or ""
                    topics_text = ", ".join(item.get("topics") or [])
                    suffix = f" Topics: {topics_text}." if topics_text else ""
                    lines.append(f"- [{item['id']}] ({item['kind']}, {item['source']}, {date}) {self._redact_text(item['content'], redact)}{suffix}")
                lines.append("")
        else:
            lines.append("- No active memories matched this focus.")
        lines.extend(["", "## Decisions", ""])
        if decisions:
            for item in decisions:
                lines.append(f"- [{item['id']}] {self._redact_text(item['content'], redact)}")
        else:
            lines.append("- No active decisions yet.")
        lines.extend(["", "## Open Loops", ""])
        if tasks:
            for task in tasks:
                lines.append(f"- [{task['id']}] ({task['kind']}) {self._redact_text(task['content'], redact)}")
        else:
            lines.append("- No open tasks or questions.")
        lines.extend(["", "## Useful Topics", ""])
        lines.append(", ".join(f"#{item['topic']}" for item in topics) if topics else "No active topics yet.")
        lines.extend(["", "## Useful Entities", ""])
        lines.append(", ".join(f"{item['name']} ({item['kind']})" for item in entities) if entities else "No active entities yet.")
        return "\n".join(lines)

    def personal_profile(self, user_id: str, query: str = "", limit: int = 6, include_pending: bool = False) -> dict[str, Any]:
        query = query.strip()
        limit = max(1, min(20, int(limit)))
        user_settings = self.settings(user_id)
        redact = bool(user_settings["redact_sensitive_context"])
        stats = self.stats(user_id)
        layer_counts = {item["layer"]: int(item["count"]) for item in stats["by_layer"]}
        layer_order = [
            ("preference", "Preference memory", "Durable likes, dislikes, defaults, and working preferences."),
            ("negative", "Negative memory", "Rejected approaches, disliked outputs, and constraints to avoid."),
            ("style", "Style memory", "Writing voice, phrasing, structure, and communication patterns."),
            ("decision", "Decision memory", "Past choices, reasons, constraints, and settled direction."),
            ("episodic", "Episodic memory", "Specific conversations, events, project moments, and recent context."),
            ("semantic", "Semantic memory", "Facts about people, projects, goals, systems, and durable context."),
        ]
        sections: list[dict[str, Any]] = []
        for layer, title, description in layer_order:
            memories = self._memories_by_layer(user_id, layer, limit=limit, include_pending=include_pending)
            sections.append(
                {
                    "layer": layer,
                    "title": title,
                    "description": description,
                    "count": layer_counts.get(layer, 0),
                    "items": [self._profile_memory_item(item, redact=redact) for item in memories],
                }
            )

        focus_memories = self.search(user_id, query, limit=limit) if query else []
        focus_memories = self._approved_profile_memories(user_id, focus_memories, include_pending=include_pending)
        open_loops = self.open_tasks(user_id, limit=limit)
        topics = self.list_topics(user_id, limit=8)
        entities = self.list_entities(user_id, limit=8)
        sources = self._source_freshness(user_id, limit=8)
        covered_layers = sum(1 for item in layer_order if layer_counts.get(item[0], 0) > 0)
        readiness = min(
            100,
            covered_layers * 12
            + min(stats["memories"], 20) * 2
            + min(stats["decisions"], 8) * 4
            + min(stats["entities"], 12) * 2
            - min(stats["pending_captures"], 8) * 2,
        )
        readiness = max(0, readiness)

        limitations: list[str] = []
        if stats["memories"] == 0:
            limitations.append("No approved memory signals exist yet, so this profile cannot adapt an assistant.")
        missing_layers = [title for layer, title, _ in layer_order if layer_counts.get(layer, 0) == 0]
        if missing_layers:
            limitations.append("Missing or weak layers: " + ", ".join(missing_layers[:4]) + ".")
        if stats["pending_captures"] and not include_pending:
            limitations.append(f"{stats['pending_captures']} pending capture(s) are excluded until approved.")
        limitations.append("This is cited retrieved memory, not a fine-tuned model or complete copy of the user.")

        profile: dict[str, Any] = {
            "generated_at": now_iso(),
            "name": "Cortex Personal Adaptation Profile",
            "query": query,
            "readiness": readiness,
            "include_pending": include_pending,
            "summary": {
                "memories": stats["memories"],
                "decisions": stats["decisions"],
                "open_loops": stats["tasks"],
                "entities": stats["entities"],
                "covered_layers": covered_layers,
                "total_layers": len(layer_order),
            },
            "coverage": {
                "by_layer": [
                    {
                        "layer": layer,
                        "title": title,
                        "count": layer_counts.get(layer, 0),
                        "status": "ready" if layer_counts.get(layer, 0) > 0 else "needs_signal",
                    }
                    for layer, title, _ in layer_order
                ],
                "sources": sources,
            },
            "focus": [self._profile_memory_item(item, redact=redact) for item in focus_memories],
            "sections": sections,
            "open_loops": [
                {
                    "id": task["id"],
                    "kind": task["kind"],
                    "content": self._redact_text(task["content"], redact),
                    "captured_at": task["captured_at"],
                    "topics": task.get("topics") or [],
                }
                for task in open_loops
            ],
            "topics": topics,
            "entities": entities,
            "limitations": limitations,
        }
        profile["markdown"] = self._personal_profile_markdown(profile)
        return profile

    def _personal_profile_markdown(self, profile: dict[str, Any]) -> str:
        lines = [
            "# Cortex Personal Adaptation Profile",
            "",
            f"Generated: {profile['generated_at']}",
            f"Readiness: {profile['readiness']}/100",
            "",
            "Use this as partial, cited memory for this conversation. It is coverage-limited and should yield to the user's newest message.",
            "",
            "## Coverage",
            "",
        ]
        for layer in profile["coverage"]["by_layer"]:
            lines.append(f"- {layer['title']}: {layer['count']} signal{'s' if layer['count'] != 1 else ''} ({layer['status']})")
        if profile["coverage"]["sources"]:
            lines.extend(["", "## Source Freshness", ""])
            for source in profile["coverage"]["sources"]:
                last_seen = source.get("last_seen") or "unknown"
                lines.append(f"- {source['source']}: {source['approved']} approved, {source['pending']} pending, last seen {last_seen}")
        if profile["focus"]:
            lines.extend(["", "## Focused Memory", ""])
            for item in profile["focus"]:
                lines.append(self._profile_markdown_item(item))
        for section in profile["sections"]:
            lines.extend(["", f"## {section['title']}", "", section["description"], ""])
            if section["items"]:
                for item in section["items"]:
                    lines.append(self._profile_markdown_item(item))
            else:
                lines.append("- No approved signals yet.")
        lines.extend(["", "## Open Loops", ""])
        if profile["open_loops"]:
            for task in profile["open_loops"]:
                lines.append(f"- [{task['id']}] ({task['kind']}) {task['content']}")
        else:
            lines.append("- No active open loops.")
        lines.extend(["", "## Topics", ""])
        lines.append(", ".join(f"#{item['topic']}" for item in profile["topics"]) if profile["topics"] else "No active topics yet.")
        lines.extend(["", "## People, Projects, And Entities", ""])
        lines.append(", ".join(f"{item['name']} ({item['kind']})" for item in profile["entities"]) if profile["entities"] else "No active entities yet.")
        lines.extend(["", "## Limitations", ""])
        for limitation in profile["limitations"]:
            lines.append(f"- {limitation}")
        return "\n".join(lines)

    def _profile_markdown_item(self, item: dict[str, Any]) -> str:
        date = item.get("captured_at") or "unknown date"
        topics = item.get("topics") or []
        topics_text = f" Topics: {', '.join(topics)}." if topics else ""
        return f"- [{item['id']}] ({item['kind']}, {item['source']}, {date}) {item['content']}{topics_text}"

    def _profile_memory_item(self, item: dict[str, Any], *, redact: bool) -> dict[str, Any]:
        return {
            "id": item["id"],
            "kind": item["kind"],
            "layer": item["layer"],
            "content": self._redact_text(item["content"], redact),
            "summary": self._redact_text(item.get("summary") or "", redact),
            "source": item["source"],
            "source_url": item.get("source_url"),
            "captured_at": item["captured_at"],
            "occurred_at": item.get("occurred_at"),
            "topics": item.get("topics") or [],
            "entity_ids": item.get("entity_ids") or [],
        }

    def _source_freshness(self, user_id: str, limit: int = 8) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT
                  source,
                  COUNT(*) AS total,
                  SUM(CASE WHEN review_status = 'approved' THEN 1 ELSE 0 END) AS approved,
                  SUM(CASE WHEN review_status = 'pending' THEN 1 ELSE 0 END) AS pending,
                  MAX(captured_at) AS last_seen
                FROM captures
                WHERE user_id = ?
                GROUP BY source
                ORDER BY total DESC, last_seen DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        return [dict(row) for row in rows]

    def _approved_profile_memories(self, user_id: str, memories: list[dict[str, Any]], *, include_pending: bool) -> list[dict[str, Any]]:
        if include_pending or not memories:
            return memories
        ids = [item["id"] for item in memories]
        placeholders = ",".join("?" for _ in ids)
        with connect(self.db_path) as conn:
            rows = conn.execute(
                f"""
                SELECT m.id
                FROM memories m
                LEFT JOIN captures c ON c.id = m.capture_id AND c.user_id = m.user_id
                WHERE m.user_id = ?
                  AND m.id IN ({placeholders})
                  AND (m.capture_id IS NULL OR c.review_status = 'approved')
                """,
                [user_id, *ids],
            ).fetchall()
        approved_ids = {row["id"] for row in rows}
        return [item for item in memories if item["id"] in approved_ids]

    def graph(self, user_id: str, limit: int = 150) -> dict[str, Any]:
        nodes: dict[str, dict[str, Any]] = {}
        edges: list[dict[str, Any]] = []
        with connect(self.db_path) as conn:
            for row in conn.execute(
                """
                SELECT id, source, title, summary, captured_at, review_status
                FROM captures
                WHERE user_id = ? AND review_status IN ('pending', 'approved')
                ORDER BY captured_at DESC
                LIMIT ?
                """,
                (user_id, limit // 3),
            ).fetchall():
                nodes[row["id"]] = {
                    "id": row["id"],
                    "type": "source",
                    "label": row["title"] or row["source"],
                    "detail": row["summary"] or "",
                    "status": row["review_status"],
                    "created_at": row["captured_at"],
                }
            for row in conn.execute(
                "SELECT id, kind, content, importance, captured_at FROM memories WHERE user_id = ? AND status = 'active' ORDER BY captured_at DESC LIMIT ?",
                (user_id, limit),
            ).fetchall():
                nodes[row["id"]] = {"id": row["id"], "type": row["kind"], "label": row["content"][:72], "importance": row["importance"], "created_at": row["captured_at"]}
            for row in conn.execute(
                """
                SELECT DISTINCT e.id, e.kind, e.name, e.context, e.last_seen
                FROM entities e
                WHERE e.user_id = ?
                  AND (
                    EXISTS (
                      SELECT 1
                      FROM memory_entities me
                      JOIN memories m ON m.id = me.memory_id AND m.user_id = me.user_id
                      WHERE me.user_id = e.user_id AND me.entity_id = e.id AND m.status = 'active'
                    )
                    OR EXISTS (
                      SELECT 1
                      FROM task_entities te
                      JOIN tasks t ON t.id = te.task_id AND t.user_id = te.user_id
                      WHERE te.user_id = e.user_id AND te.entity_id = e.id AND t.status = 'open'
                    )
                  )
                ORDER BY e.last_seen DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall():
                nodes[row["id"]] = {"id": row["id"], "type": row["kind"], "label": row["name"], "detail": row["context"] or ""}
            for row in conn.execute("SELECT id, kind, content, status FROM tasks WHERE user_id = ? AND status = 'open' ORDER BY captured_at DESC LIMIT ?", (user_id, limit // 2)).fetchall():
                nodes[row["id"]] = {"id": row["id"], "type": row["kind"], "label": row["content"][:72], "status": row["status"]}
            for row in conn.execute(
                """
                SELECT ge.*
                FROM graph_edges ge
                LEFT JOIN captures c ON c.id = ge.evidence_id AND c.user_id = ge.user_id
                LEFT JOIN memories m ON m.id = ge.evidence_id AND m.user_id = ge.user_id
                LEFT JOIN tasks t ON t.id = ge.evidence_id AND t.user_id = ge.user_id
                WHERE ge.user_id = ?
                  AND (
                    ge.evidence_id IS NULL
                    OR c.review_status IN ('pending', 'approved')
                    OR m.status = 'active'
                    OR t.status = 'open'
                  )
                ORDER BY ge.created_at DESC
                LIMIT ?
                """,
                (user_id, limit * 2),
            ).fetchall():
                if row["source_id"] in nodes and row["target_id"] in nodes:
                    edges.append(dict(row))
        return {"nodes": list(nodes.values()), "edges": edges}

    def export_json(self, user_id: str) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            captures = [self._capture_from_row(row) for row in conn.execute("SELECT * FROM captures WHERE user_id = ? ORDER BY captured_at DESC", (user_id,)).fetchall()]
            memories = [self._memory_from_row(row) for row in conn.execute("SELECT * FROM memories WHERE user_id = ? ORDER BY captured_at DESC", (user_id,)).fetchall()]
            tasks = [self._task_from_row(row) for row in conn.execute("SELECT * FROM tasks WHERE user_id = ? ORDER BY captured_at DESC", (user_id,)).fetchall()]
            entities = [self._entity_from_row(row) for row in conn.execute("SELECT * FROM entities WHERE user_id = ? ORDER BY last_seen DESC", (user_id,)).fetchall()]
            edges = [dict(row) for row in conn.execute("SELECT * FROM graph_edges WHERE user_id = ? ORDER BY created_at DESC", (user_id,)).fetchall()]
        payload = {
            "exported_at": now_iso(),
            "user_id": user_id,
            "stats": self.stats(user_id),
            "captures": captures,
            "memories": memories,
            "tasks": tasks,
            "entities": entities,
            "edges": edges,
        }
        if self.settings(user_id)["redact_sensitive_context"]:
            return self._redact_payload(payload)
        return payload

    def diagnostics(self, user_id: str) -> dict[str, Any]:
        db_size = self.db_path.stat().st_size if self.db_path.exists() else 0
        wal_path = self.db_path.with_name(self.db_path.name + "-wal")
        wal_size = wal_path.stat().st_size if wal_path.exists() else 0
        with connect(self.db_path) as conn:
            quick_check = conn.execute("PRAGMA quick_check").fetchone()[0]
            schema_version = conn.execute("PRAGMA user_version").fetchone()[0]
            vector_status = sqlite_vec_status(conn)
            counts = {
                "captures": conn.execute("SELECT COUNT(*) FROM captures WHERE user_id = ?", (user_id,)).fetchone()[0],
                "active_memories": conn.execute("SELECT COUNT(*) FROM memories WHERE user_id = ? AND status = 'active'", (user_id,)).fetchone()[0],
                "archived_memories": conn.execute("SELECT COUNT(*) FROM memories WHERE user_id = ? AND status = 'archived'", (user_id,)).fetchone()[0],
                "open_tasks": conn.execute("SELECT COUNT(*) FROM tasks WHERE user_id = ? AND status = 'open'", (user_id,)).fetchone()[0],
                "events": conn.execute("SELECT COUNT(*) FROM memory_events WHERE user_id = ?", (user_id,)).fetchone()[0],
                "vector_embeddings": self._vector_count(conn, user_id),
                "queued_jobs": conn.execute("SELECT COUNT(*) FROM memory_jobs WHERE user_id = ? AND status = 'queued'", (user_id,)).fetchone()[0],
                "running_jobs": conn.execute("SELECT COUNT(*) FROM memory_jobs WHERE user_id = ? AND status = 'running'", (user_id,)).fetchone()[0],
                "failed_jobs": conn.execute("SELECT COUNT(*) FROM memory_jobs WHERE user_id = ? AND status = 'failed'", (user_id,)).fetchone()[0],
            }
            fts_orphans = conn.execute(
                """
                SELECT COUNT(*)
                FROM memory_fts f
                LEFT JOIN memories m ON m.id = f.memory_id
                WHERE m.id IS NULL
                """
            ).fetchone()[0]
            inactive_fts_rows = conn.execute(
                """
                SELECT COUNT(*)
                FROM memory_fts f
                JOIN memories m ON m.id = f.memory_id
                WHERE m.status != 'active'
                """
            ).fetchone()[0]
            relation_orphans = conn.execute(
                """
                SELECT
                  (SELECT COUNT(*) FROM memory_entities me LEFT JOIN memories m ON m.id = me.memory_id WHERE m.id IS NULL) +
                  (SELECT COUNT(*) FROM memory_topics mt LEFT JOIN memories m ON m.id = mt.memory_id WHERE m.id IS NULL) +
                  (SELECT COUNT(*) FROM task_entities te LEFT JOIN tasks t ON t.id = te.task_id WHERE t.id IS NULL) +
                  (SELECT COUNT(*) FROM task_topics tt LEFT JOIN tasks t ON t.id = tt.task_id WHERE t.id IS NULL)
                """
            ).fetchone()[0]
            last_event_at = conn.execute("SELECT MAX(created_at) FROM memory_events WHERE user_id = ?", (user_id,)).fetchone()[0]
        issue_count = int(quick_check != "ok") + fts_orphans + inactive_fts_rows + relation_orphans
        vault_diagnostics = self.vault.diagnostics()
        issue_count += len(vault_diagnostics["missing_dirs"])
        return {
            "status": "ok" if issue_count == 0 else "needs_maintenance",
            "quick_check": quick_check,
            "schema_version": schema_version,
            "db_path": str(self.db_path),
            "db_size_bytes": db_size,
            "wal_size_bytes": wal_size,
            "counts": counts,
            "fts_orphans": fts_orphans,
            "inactive_fts_rows": inactive_fts_rows,
            "relation_orphans": relation_orphans,
            "last_event_at": last_event_at,
            "vector": vector_status,
            "embedding": embedding_status(),
            "vault": vault_diagnostics,
        }

    def health_payload(self, *, mode: str, auth: bool) -> dict[str, Any]:
        return {
            "status": "ok",
            "backend_version": BACKEND_VERSION,
            "health_contract": HEALTH_CONTRACT,
            "features": list(BACKEND_FEATURES),
            "mode": mode,
            "db_path": str(self.db_path),
            "vault_path": str(self.vault.root),
            "auth": auth,
        }

    def reliability_report(self, user_id: str) -> dict[str, Any]:
        diagnostics = self.diagnostics(user_id)
        latest_backup = self.latest_backup()
        checks: list[dict[str, Any]] = []

        def add_check(
            name: str,
            title: str,
            status: str,
            detail: str,
            action: str | None = None,
        ) -> None:
            checks.append(
                {
                    "name": name,
                    "title": title,
                    "status": status,
                    "detail": detail,
                    "action": action,
                }
            )

        add_check(
            "sqlite_quick_check",
            "SQLite integrity",
            "ok" if diagnostics["quick_check"] == "ok" else "critical",
            f"PRAGMA quick_check returned {diagnostics['quick_check']}.",
            None if diagnostics["quick_check"] == "ok" else "Restore from backup or export the vault before using this index.",
        )

        fts_issues = diagnostics["fts_orphans"] + diagnostics["inactive_fts_rows"]
        add_check(
            "search_index",
            "Search index",
            "ok" if fts_issues == 0 else "warn",
            f"{fts_issues} stale or orphaned full-text search rows.",
            None if fts_issues == 0 else "Run storage repair or rebuild search.",
        )

        add_check(
            "relationships",
            "Relationship tables",
            "ok" if diagnostics["relation_orphans"] == 0 else "warn",
            f"{diagnostics['relation_orphans']} orphaned relationship rows.",
            None if diagnostics["relation_orphans"] == 0 else "Run storage repair.",
        )

        missing_dirs = diagnostics.get("vault", {}).get("missing_dirs", []) if diagnostics.get("vault") else []
        add_check(
            "vault_layout",
            "Vault layout",
            "ok" if not missing_dirs else "warn",
            "Vault folders are present." if not missing_dirs else "Missing folders: " + ", ".join(missing_dirs),
            None if not missing_dirs else "Restart Cortex or create a backup to recreate missing folders.",
        )

        if latest_backup:
            age_days = latest_backup.get("age_days")
            backup_status = "ok" if isinstance(age_days, int) and age_days <= 7 else "warn"
            backup_detail = f"Latest backup is {age_days} day{'s' if age_days != 1 else ''} old."
        else:
            backup_status = "warn"
            backup_detail = "No local backup has been created yet."
        add_check(
            "backup_recency",
            "Backup recency",
            backup_status,
            backup_detail,
            None if backup_status == "ok" else "Create a backup before relying on this vault.",
        )

        vector = diagnostics.get("vector") or {}
        vector_status = "ok" if vector.get("available") else "warn"
        add_check(
            "vector_index",
            "Vector search",
            vector_status,
            "sqlite-vec is available." if vector.get("available") else str(vector.get("reason") or "sqlite-vec is not available; keyword search remains enabled."),
            None if vector_status == "ok" else "Install sqlite-vec when semantic search becomes required for this build.",
        )

        if any(check["status"] == "critical" for check in checks):
            status = "critical"
        elif any(check["status"] == "warn" for check in checks):
            status = "needs_attention"
        else:
            status = "ok"

        recommended_actions = [
            check["action"]
            for check in checks
            if check.get("action")
        ]
        if status == "ok":
            recommended_actions = ["No action needed. Keep using Cortex and keep periodic backups enabled."]

        return {
            "status": status,
            "generated_at": now_iso(),
            "backend_version": BACKEND_VERSION,
            "health_contract": HEALTH_CONTRACT,
            "features": list(BACKEND_FEATURES),
            "checks": checks,
            "recommended_actions": recommended_actions,
            "latest_backup": latest_backup,
            "diagnostics": diagnostics,
        }

    def support_bundle(self, user_id: str) -> dict[str, Any]:
        diagnostics = self.diagnostics(user_id)
        reliability = self.reliability_report(user_id)
        trust = self.trust_summary(user_id)
        stats = self.stats(user_id)
        loop = self.product_loop(user_id)
        recent_events = [self._support_event_summary(event) for event in self.audit_log(user_id, limit=30)]
        latest_backup = self.latest_backup()

        return {
            "bundle_schema": SUPPORT_BUNDLE_SCHEMA,
            "generated_at": now_iso(),
            "privacy": {
                "contains_raw_capture_text": False,
                "contains_memory_content": False,
                "contains_context_pack": False,
                "contains_user_files": False,
                "review_before_sharing": True,
                "notes": [
                    "This bundle is designed for support triage and omits captured text, memory bodies, memory views, and exported user data.",
                    "It may include local paths shortened to use ~, record counts, health checks, feature flags, and safe event metadata.",
                ],
            },
            "backend": {
                "version": BACKEND_VERSION,
                "health_contract": HEALTH_CONTRACT,
                "features": list(BACKEND_FEATURES),
                "sqlite_version": sqlite3.sqlite_version,
            },
            "runtime": {
                "python_version": sys.version.split()[0],
                "platform": platform.platform(),
            },
            "summary": {
                "status": reliability["status"],
                "trust_mode": trust["mode"],
                "trust_score": trust["trust_score"],
                "recommended_actions": reliability["recommended_actions"],
                "latest_backup_age_days": latest_backup.get("age_days") if latest_backup else None,
                "counts": {
                    "captures": stats["captures"],
                    "pending_captures": stats["pending_captures"],
                    "active_memories": stats["memories"],
                    "open_tasks": stats["tasks"],
                    "events": diagnostics["counts"].get("events", 0),
                    "vault_backups": diagnostics.get("vault", {}).get("record_counts", {}).get("backups", 0),
                },
            },
            "health": self._support_safe_payload(self.health_payload(mode="local", auth=True)),
            "diagnostics": self._support_safe_payload(diagnostics),
            "reliability": self._support_safe_payload(reliability),
            "trust": self._support_safe_payload(trust),
            "product_loop": self._support_safe_payload(
                {
                    "status": loop.get("status"),
                    "completion": loop.get("completion"),
                    "primary_action": loop.get("primary_action"),
                    "counts": loop.get("counts"),
                    "last_reused_at": loop.get("last_reused_at"),
                    "today": loop.get("today"),
                }
            ),
            "recent_events": recent_events,
        }

    def latest_backup(self) -> dict[str, Any] | None:
        backup_dir = self.vault.backups_dir
        if not backup_dir.exists():
            return None
        backups = sorted(
            (path for path in backup_dir.glob("*.zip") if path.is_file()),
            key=lambda path: (path.stat().st_mtime, path.name),
            reverse=True,
        )
        if not backups:
            return None
        path = backups[0]
        modified = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc)
        age_seconds = max(0, (datetime.now(timezone.utc) - modified).total_seconds())
        return {
            "backup_path": str(path),
            "size_bytes": path.stat().st_size,
            "created_at": modified.isoformat().replace("+00:00", "Z"),
            "age_days": int(age_seconds // 86400),
        }

    def repair_storage(self, user_id: str) -> dict[str, Any]:
        before = self.diagnostics(user_id)
        backup = self.create_backup(user_id)
        actions: list[dict[str, Any]] = []

        def deleted_rows(cursor: sqlite3.Cursor) -> int:
            return cursor.rowcount if cursor.rowcount is not None and cursor.rowcount >= 0 else 0

        with connect(self.db_path) as conn:
            cleanup_statements = [
                (
                    "remove_fts_orphans",
                    """
                    DELETE FROM memory_fts
                    WHERE memory_id NOT IN (SELECT id FROM memories)
                    """,
                    (),
                ),
                (
                    "remove_inactive_fts",
                    """
                    DELETE FROM memory_fts
                    WHERE memory_id IN (
                      SELECT id FROM memories WHERE user_id = ? AND status != 'active'
                    )
                    """,
                    (user_id,),
                ),
                (
                    "remove_memory_entity_orphans",
                    """
                    DELETE FROM memory_entities
                    WHERE user_id = ? AND memory_id NOT IN (SELECT id FROM memories)
                    """,
                    (user_id,),
                ),
                (
                    "remove_memory_topic_orphans",
                    """
                    DELETE FROM memory_topics
                    WHERE user_id = ? AND memory_id NOT IN (SELECT id FROM memories)
                    """,
                    (user_id,),
                ),
                (
                    "remove_task_entity_orphans",
                    """
                    DELETE FROM task_entities
                    WHERE user_id = ? AND task_id NOT IN (SELECT id FROM tasks)
                    """,
                    (user_id,),
                ),
                (
                    "remove_task_topic_orphans",
                    """
                    DELETE FROM task_topics
                    WHERE user_id = ? AND task_id NOT IN (SELECT id FROM tasks)
                    """,
                    (user_id,),
                ),
                (
                    "remove_graph_edge_orphans",
                    """
                    DELETE FROM graph_edges
                    WHERE user_id = ?
                      AND evidence_id IS NOT NULL
                      AND evidence_id NOT IN (SELECT id FROM memories)
                      AND evidence_id NOT IN (SELECT id FROM tasks)
                      AND evidence_id NOT IN (SELECT id FROM captures)
                    """,
                    (user_id,),
                ),
            ]
            for name, statement, parameters in cleanup_statements:
                cursor = conn.execute(statement, parameters)
                actions.append({"name": name, "rows": deleted_rows(cursor)})
            conn.execute("PRAGMA optimize")
            self._event(
                conn,
                user_id,
                str(self.db_path),
                "maintenance",
                "storage_repair_cleanup",
                {"actions": actions, "backup_path": backup["backup_path"]},
            )

        rebuild = self.rebuild_search_index(user_id)
        actions.append({"name": "rebuild_search_index", "rows": rebuild["indexed_memories"]})
        after = self.diagnostics(user_id)
        return {
            "repaired_at": now_iso(),
            "backup_path": backup["backup_path"],
            "before": before,
            "after": after,
            "actions": actions,
        }

    def create_backup(self, user_id: str) -> dict[str, Any]:
        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H-%M-%S-%fZ")
        backup_dir = self.vault.backups_dir
        backup_dir.mkdir(parents=True, exist_ok=True)
        sqlite_backup_path = backup_dir / f"index-{timestamp}.sqlite"
        source = sqlite3.connect(self.db_path)
        target = sqlite3.connect(sqlite_backup_path)
        try:
            source.backup(target)
        finally:
            target.close()
            source.close()
        backup_path = self.vault.create_zip_backup(timestamp, sqlite_backup_path)
        try:
            sqlite_backup_path.unlink()
        except FileNotFoundError:
            pass
        with connect(self.db_path) as conn:
            self._event(
                conn,
                user_id,
                str(backup_path),
                "backup",
                "created",
                {"size_bytes": backup_path.stat().st_size, "format": "cortex-vault-zip"},
            )
        retention = backup_retention_policy()
        pruned = self.prune_backups(
            user_id,
            keep_latest=retention["keep_latest"],
            max_age_days=retention["max_age_days"],
        )
        return {
            "backup_path": str(backup_path),
            "size_bytes": backup_path.stat().st_size,
            "created_at": now_iso(),
            "retention": retention,
            "pruned_backups": pruned,
        }

    def delete_backups(self, user_id: str) -> dict[str, Any]:
        deleted_at = now_iso()
        result = self.vault.delete_backups()
        with connect(self.db_path) as conn:
            self._event(
                conn,
                user_id,
                str(self.vault.backups_dir),
                "backup",
                "deleted",
                {"deleted": result["deleted"], "bytes_deleted": result["bytes_deleted"]},
            )
        return {"deleted_at": deleted_at, **result}

    def prune_backups(self, user_id: str, *, keep_latest: int = 20, max_age_days: int = 0) -> dict[str, Any]:
        pruned_at = now_iso()
        result = self.vault.prune_backups(keep_latest=keep_latest, max_age_days=max_age_days)
        if result["deleted"]:
            with connect(self.db_path) as conn:
                self._event(
                    conn,
                    user_id,
                    str(self.vault.backups_dir),
                    "backup",
                    "pruned",
                    {
                        "deleted": result["deleted"],
                        "bytes_deleted": result["bytes_deleted"],
                        "retention": result["retention"],
                    },
                )
        return {"pruned_at": pruned_at, **result}

    def delete_user_data(self, user_id: str, *, include_backups: bool = True) -> dict[str, Any]:
        deleted_at = now_iso()
        with connect(self.db_path) as conn:
            counts = {
                "captures": conn.execute("SELECT COUNT(*) FROM captures WHERE user_id = ?", (user_id,)).fetchone()[0],
                "memories": conn.execute("SELECT COUNT(*) FROM memories WHERE user_id = ?", (user_id,)).fetchone()[0],
                "tasks": conn.execute("SELECT COUNT(*) FROM tasks WHERE user_id = ?", (user_id,)).fetchone()[0],
                "entities": conn.execute("SELECT COUNT(*) FROM entities WHERE user_id = ?", (user_id,)).fetchone()[0],
                "graph_edges": conn.execute("SELECT COUNT(*) FROM graph_edges WHERE user_id = ?", (user_id,)).fetchone()[0],
                "events": conn.execute("SELECT COUNT(*) FROM memory_events WHERE user_id = ?", (user_id,)).fetchone()[0],
                "settings": conn.execute("SELECT COUNT(*) FROM user_settings WHERE user_id = ?", (user_id,)).fetchone()[0],
                "api_tokens": conn.execute("SELECT COUNT(*) FROM api_tokens WHERE user_id = ?", (user_id,)).fetchone()[0],
                "memory_jobs": conn.execute("SELECT COUNT(*) FROM memory_jobs WHERE user_id = ?", (user_id,)).fetchone()[0],
                "capture_processing_state": conn.execute("SELECT COUNT(*) FROM capture_processing_state WHERE user_id = ?", (user_id,)).fetchone()[0],
            }
            self._clear_user_vectors(conn, user_id)
            conn.execute("DELETE FROM memory_fts WHERE memory_id IN (SELECT id FROM memories WHERE user_id = ?)", (user_id,))
            conn.execute("DELETE FROM memory_entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_topics WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM task_entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM task_topics WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM graph_edges WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM tasks WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memories WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_jobs WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM capture_processing_state WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM captures WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_events WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM user_settings WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM api_tokens WHERE user_id = ?", (user_id,))
            vault_counts = self.vault.delete_user_records(user_id, include_backups=include_backups)
        return {
            "deleted_at": deleted_at,
            "include_backups": include_backups,
            "sqlite": counts,
            "vault": vault_counts,
        }

    def restore_latest_backup(self, user_id: str) -> dict[str, Any]:
        latest = self.latest_backup()
        if not latest:
            raise FileNotFoundError("No Cortex backup archives are available")
        preserved_tombstones = list(self.vault.iter_tombstones(user_id))
        restored = self.vault.restore_from_zip_backup(Path(latest["backup_path"]))
        for tombstone in preserved_tombstones:
            self.vault.write_tombstone_record(tombstone)
        rebuild = self.rebuild_index_from_vault(user_id)
        restored_at = now_iso()
        with connect(self.db_path) as conn:
            self._event(
                conn,
                user_id,
                latest["backup_path"],
                "backup",
                "restored",
                {
                    "captures": rebuild["captures"],
                    "memories": rebuild["memories"],
                    "tasks": rebuild["tasks"],
                    "tombstones": rebuild.get("tombstones", {}),
                },
            )
        return {
            "restored_at": restored_at,
            "backup_path": latest["backup_path"],
            "size_bytes": latest["size_bytes"],
            "vault": restored,
            "rebuild": rebuild,
            "tombstones": rebuild.get("tombstones", {}),
        }

    def rebuild_search_index(self, user_id: str) -> dict[str, Any]:
        with connect(self.db_path) as conn:
            conn.execute(
                """
                DELETE FROM memory_fts
                WHERE memory_id IN (SELECT id FROM memories WHERE user_id = ?)
                """,
                (user_id,),
            )
            self._clear_user_vectors(conn, user_id)
            rows = conn.execute(
                """
                SELECT id, capture_id, kind, layer, content, summary, source, topics_json, captured_at
                FROM memories
                WHERE user_id = ? AND status = 'active'
                """,
                (user_id,),
            ).fetchall()
            queued_vectors = 0
            for row in rows:
                topics = " ".join(json.loads(row["topics_json"] or "[]"))
                conn.execute(
                    "INSERT INTO memory_fts(memory_id, content, summary, source, topics) VALUES (?, ?, ?, ?, ?)",
                    (row["id"], row["content"], row["summary"], row["source"], topics),
                )
                job = self._enqueue_embed_memory_job(
                    conn,
                    memory_id=row["id"],
                    capture_id=row["capture_id"],
                    user_id=user_id,
                    content=row["content"],
                    summary=row["summary"],
                    source=row["source"],
                    layer=memory_layer(row["kind"], row["layer"]),
                    topics=json.loads(row["topics_json"] or "[]"),
                    captured_at=row["captured_at"] or now_iso(),
                    priority=90,
                )
                if job and job["status"] == "queued":
                    queued_vectors += 1
            vector_count = self._vector_count(conn, user_id)
            vector_available = self._vector_ready(conn)
            self._event(conn, user_id, "memory_fts", "maintenance", "rebuilt_search_index", {"indexed_memories": len(rows), "vector_indexed_memories": vector_count, "vector_queued_memories": queued_vectors})
        return {
            "indexed_memories": len(rows),
            "rebuilt_at": now_iso(),
            "vector_available": vector_available,
            "vector_indexed_memories": vector_count,
            "vector_queued_memories": queued_vectors,
            "vector_model": embedding_status()["model"],
            "embedding": embedding_status(),
        }

    def rebuild_vectors(self, user_id: str) -> dict[str, Any]:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT id, capture_id, kind, layer, content, summary, source, topics_json, captured_at
                FROM memories
                WHERE user_id = ? AND status = 'active'
                """,
                (user_id,),
            ).fetchall()
            vector_available = self._vector_ready(conn)
            if not vector_available:
                return {
                    "queued": 0,
                    "skipped": len(rows),
                    "checked": len(rows),
                    "rebuilt_at": timestamp,
                    "vector_available": False,
                    "vector_indexed_memories": self._vector_count(conn, user_id),
                    "vector_model": embedding_status()["model"],
                    "embedding": embedding_status(),
                }
            queued = 0
            skipped = 0
            for row in rows:
                job = self._enqueue_embed_memory_job(
                    conn,
                    memory_id=row["id"],
                    capture_id=row["capture_id"],
                    user_id=user_id,
                    content=row["content"],
                    summary=row["summary"],
                    source=row["source"],
                    layer=memory_layer(row["kind"], row["layer"]),
                    topics=json.loads(row["topics_json"] or "[]"),
                    captured_at=row["captured_at"] or timestamp,
                    priority=90,
                )
                if job and job["status"] == "queued":
                    queued += 1
                else:
                    skipped += 1
            vector_count = self._vector_count(conn, user_id)
            self._event(
                conn,
                user_id,
                "memory_vec",
                "maintenance",
                "queued_vector_rebuild",
                {"checked": len(rows), "queued": queued, "skipped": skipped, "vector_indexed_memories": vector_count},
            )
        return {
            "queued": queued,
            "skipped": skipped,
            "checked": len(rows),
            "rebuilt_at": timestamp,
            "vector_available": vector_available,
            "vector_indexed_memories": vector_count,
            "vector_model": embedding_status()["model"],
            "embedding": embedding_status(),
        }

    def rebuild_index_from_vault(self, user_id: str) -> dict[str, Any]:
        tombstone_counts = self.vault.apply_tombstones(user_id)
        captures = list(self.vault.iter_records("captures", user_id))
        memories = list(self.vault.iter_records("memories", user_id))
        tasks = list(self.vault.iter_records("tasks", user_id))
        entities = list(self.vault.iter_records("entities", user_id))
        edges = list(self.vault.iter_records("graph_edges", user_id))
        events = list(self.vault.iter_events(user_id))
        settings = self.vault.read_settings(user_id) or dict(DEFAULT_USER_SETTINGS)
        timestamp = now_iso()

        with connect(self.db_path) as conn:
            self._clear_user_vectors(conn, user_id)
            conn.execute("DELETE FROM memory_fts WHERE memory_id IN (SELECT id FROM memories WHERE user_id = ?)", (user_id,))
            conn.execute("DELETE FROM memory_entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_topics WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM task_entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM task_topics WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM graph_edges WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM tasks WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memories WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM entities WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM captures WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM memory_events WHERE user_id = ?", (user_id,))
            conn.execute("DELETE FROM user_settings WHERE user_id = ?", (user_id,))

            for key, value in settings.items():
                if key in DEFAULT_USER_SETTINGS:
                    conn.execute(
                        "INSERT OR REPLACE INTO user_settings(user_id, key, value_json, updated_at) VALUES (?, ?, ?, ?)",
                        (user_id, key, json.dumps(value), timestamp),
                    )

            for capture in sorted(captures, key=lambda item: item.get("captured_at") or ""):
                conn.execute(
                    """
                    INSERT OR REPLACE INTO captures
                    (id, user_id, source, source_url, title, raw_text, raw_hash, summary, review_status, approved_at, archived_at, captured_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        capture["id"],
                        user_id,
                        capture.get("source", "vault"),
                        capture.get("source_url"),
                        capture.get("title"),
                        capture.get("raw_text", ""),
                        capture.get("raw_hash"),
                        capture.get("summary", ""),
                        capture.get("review_status", "pending"),
                        capture.get("approved_at"),
                        capture.get("archived_at"),
                        capture.get("captured_at") or timestamp,
                    ),
                )

            for entity in sorted(entities, key=lambda item: item.get("id") or ""):
                conn.execute(
                    """
                    INSERT OR REPLACE INTO entities
                    (id, user_id, kind, name, aliases_json, context, first_seen, last_seen)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        entity["id"],
                        user_id,
                        entity.get("kind", "person"),
                        entity.get("name", entity["id"]),
                        json.dumps(entity.get("aliases", [])),
                        entity.get("context", ""),
                        entity.get("first_seen") or timestamp,
                        entity.get("last_seen") or timestamp,
                    ),
                )

            for memory in sorted(memories, key=lambda item: item.get("captured_at") or ""):
                topics = memory.get("topics", [])
                entity_ids = memory.get("entity_ids", [])
                captured_at = memory.get("captured_at") or timestamp
                conn.execute(
                    """
                    INSERT OR REPLACE INTO memories
                    (id, capture_id, user_id, kind, layer, content, summary, source, source_url, confidence, importance, status, topics_json, entity_ids_json, occurred_at, captured_at, updated_at, raw_excerpt)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        memory["id"],
                        memory.get("capture_id"),
                        user_id,
                        memory.get("kind", "observation"),
                        memory_layer(memory.get("kind", "observation"), memory.get("layer")),
                        memory.get("content", ""),
                        memory.get("summary", ""),
                        memory.get("source", "vault"),
                        memory.get("source_url"),
                        memory.get("confidence", "confirmed"),
                        int(memory.get("importance", 3)),
                        memory.get("status", "active"),
                        json.dumps(topics),
                        json.dumps(entity_ids),
                        memory.get("occurred_at"),
                        captured_at,
                        memory.get("updated_at") or captured_at,
                        memory.get("raw_excerpt"),
                    ),
                )
                if memory.get("status", "active") == "active":
                    conn.execute(
                        "INSERT INTO memory_fts(memory_id, content, summary, source, topics) VALUES (?, ?, ?, ?, ?)",
                        (memory["id"], memory.get("content", ""), memory.get("summary", ""), memory.get("source", "vault"), " ".join(topics)),
                    )
                    self._enqueue_embed_memory_job(
                        conn,
                        memory_id=memory["id"],
                        capture_id=memory.get("capture_id"),
                        user_id=user_id,
                        content=memory.get("content", ""),
                        summary=memory.get("summary", ""),
                        source=memory.get("source", "vault"),
                        layer=memory_layer(memory.get("kind", "observation"), memory.get("layer")),
                        topics=topics,
                        captured_at=captured_at,
                        priority=90,
                    )
                for entity_id in entity_ids:
                    conn.execute(
                        "INSERT OR REPLACE INTO memory_entities(memory_id, entity_id, user_id, created_at) VALUES (?, ?, ?, ?)",
                        (memory["id"], entity_id, user_id, captured_at),
                    )
                for topic in topics:
                    conn.execute(
                        "INSERT OR REPLACE INTO memory_topics(memory_id, topic, user_id, created_at) VALUES (?, ?, ?, ?)",
                        (memory["id"], topic, user_id, captured_at),
                    )

            for task in sorted(tasks, key=lambda item: item.get("captured_at") or ""):
                topics = task.get("topics", [])
                entity_ids = task.get("entity_ids", [])
                captured_at = task.get("captured_at") or timestamp
                conn.execute(
                    """
                    INSERT OR REPLACE INTO tasks
                    (id, capture_id, user_id, kind, content, status, importance, topics_json, entity_ids_json, captured_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        task["id"],
                        task.get("capture_id"),
                        user_id,
                        task.get("kind", "action"),
                        task.get("content", ""),
                        task.get("status", "open"),
                        int(task.get("importance", 3)),
                        json.dumps(topics),
                        json.dumps(entity_ids),
                        captured_at,
                    ),
                )
                for entity_id in entity_ids:
                    conn.execute(
                        "INSERT OR REPLACE INTO task_entities(task_id, entity_id, user_id, created_at) VALUES (?, ?, ?, ?)",
                        (task["id"], entity_id, user_id, captured_at),
                    )
                for topic in topics:
                    conn.execute(
                        "INSERT OR REPLACE INTO task_topics(task_id, topic, user_id, created_at) VALUES (?, ?, ?, ?)",
                        (task["id"], topic, user_id, captured_at),
                    )

            for edge in edges:
                conn.execute(
                    "INSERT OR REPLACE INTO graph_edges(id, user_id, source_id, target_id, kind, weight, evidence_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        edge["id"],
                        user_id,
                        edge.get("source_id", ""),
                        edge.get("target_id", ""),
                        edge.get("kind", "related"),
                        float(edge.get("weight", 1.0)),
                        edge.get("evidence_id"),
                        edge.get("created_at") or timestamp,
                    ),
                )

            for event in events:
                conn.execute(
                    "INSERT OR REPLACE INTO memory_events(id, user_id, object_id, object_type, event_type, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (
                        event["id"],
                        user_id,
                        event.get("object_id", ""),
                        event.get("object_type", "unknown"),
                        event.get("event_type", "unknown"),
                        json.dumps(event.get("metadata", {})),
                        event.get("created_at") or timestamp,
                    ),
                )

            self._event(
                conn,
                user_id,
                str(self.vault.root),
                "index",
                "rebuilt_from_vault",
                {
                    "captures": len(captures),
                    "memories": len(memories),
                    "tasks": len(tasks),
                    "entities": len(entities),
                    "edges": len(edges),
                    "events": len(events),
                    "tombstones": tombstone_counts,
                },
            )

        return {
            "rebuilt_at": timestamp,
            "vault_path": str(self.vault.root),
            "index_path": str(self.db_path),
            "captures": len(captures),
            "memories": len(memories),
            "tasks": len(tasks),
            "entities": len(entities),
            "edges": len(edges),
            "events": len(events),
            "tombstones": tombstone_counts,
        }

    def export_markdown(self, user_id: str) -> str:
        data = self.export_json(user_id)
        lines = ["# Cortex Export", "", f"Exported: {data['exported_at']}", "", "## Stats", ""]
        for key, value in data["stats"].items():
            if not isinstance(value, list):
                lines.append(f"- {key}: {value}")
        lines.extend(["", "## Memories", ""])
        for memory in data["memories"]:
            layer = memory_layer(memory.get("kind"), memory.get("layer")).title()
            lines.append(f"### {layer} / {memory['kind'].title()} - {memory['source']} - {memory['captured_at']}")
            lines.append("")
            lines.append(memory["content"])
            topics = memory.get("topics") or []
            if topics:
                lines.append("")
                lines.append("Topics: " + ", ".join(topics))
            lines.append("")
        lines.extend(["## Open Tasks", ""])
        for task in data["tasks"]:
            if task.get("status") == "open":
                lines.append(f"- [{task['kind']}] {task['content']}")
        return "\n".join(lines)

    def trust_summary(self, user_id: str) -> dict[str, Any]:
        user_settings = self.settings(user_id)
        stats = self.stats(user_id)
        diagnostics = self.diagnostics(user_id)
        with connect(self.db_path) as conn:
            source_rows = conn.execute(
                """
                SELECT
                  source,
                  COUNT(*) AS total,
                  SUM(CASE WHEN review_status = 'pending' THEN 1 ELSE 0 END) AS pending,
                  SUM(CASE WHEN review_status = 'approved' THEN 1 ELSE 0 END) AS approved,
                  SUM(CASE WHEN review_status = 'archived' THEN 1 ELSE 0 END) AS archived,
                  MAX(captured_at) AS last_seen
                FROM captures
                WHERE user_id = ?
                GROUP BY source
                ORDER BY total DESC, last_seen DESC
                LIMIT 16
                """,
                (user_id,),
            ).fetchall()
            recent_agent_events = conn.execute(
                """
                SELECT COUNT(*)
                FROM memory_events
                WHERE user_id = ?
                  AND object_type = 'agent'
                  AND created_at >= datetime('now', '-7 days')
                """,
                (user_id,),
            ).fetchone()[0]
            last_agent_event = conn.execute(
                """
                SELECT MAX(created_at)
                FROM memory_events
                WHERE user_id = ? AND object_type = 'agent'
                """,
                (user_id,),
            ).fetchone()[0]

        risk_flags: list[str] = []
        if not user_settings["review_new_captures"]:
            risk_flags.append("New saves are approved automatically.")
        if user_settings["allow_pending_in_context"]:
            risk_flags.append("Pending saves can appear in assistant context.")
        if user_settings["allow_agent_writes"]:
            risk_flags.append("Connected agents can write to memory.")
        if user_settings["allow_agent_exports"]:
            risk_flags.append("Connected agents can export or prepare memory handoffs.")
        if user_settings["allow_agent_maintenance"]:
            risk_flags.append("Connected agents can run maintenance actions.")
        if user_settings["allow_agent_destructive_actions"]:
            risk_flags.append("Connected agents can run destructive actions.")
        if not user_settings["redact_sensitive_context"]:
            risk_flags.append("Sensitive-pattern redaction is off for shared context.")
        if diagnostics["status"] != "ok":
            risk_flags.append("Storage health needs maintenance.")

        score = 100
        score -= 16 if user_settings["allow_pending_in_context"] else 0
        score -= 12 if not user_settings["review_new_captures"] else 0
        score -= 12 if user_settings["allow_agent_writes"] else 0
        score -= 10 if user_settings["allow_agent_exports"] else 0
        score -= 10 if user_settings["allow_agent_maintenance"] else 0
        score -= 18 if user_settings["allow_agent_destructive_actions"] else 0
        score -= 18 if not user_settings["redact_sensitive_context"] else 0
        score -= min(20, stats["pending_captures"] * 2)
        score -= 12 if diagnostics["status"] != "ok" else 0
        score = max(0, min(100, score))
        if score >= 80:
            mode = "guarded"
        elif score >= 55:
            mode = "balanced"
        else:
            mode = "open"

        return {
            "generated_at": now_iso(),
            "trust_score": score,
            "mode": mode,
            "settings": user_settings,
            "counts": {
                "captures": stats["captures"],
                "pending_captures": stats["pending_captures"],
                "active_memories": stats["memories"],
                "open_tasks": stats["tasks"],
                "audit_events": diagnostics["counts"].get("events", 0),
                "agent_events_7d": recent_agent_events,
            },
            "risk_flags": risk_flags,
            "source_counts": [dict(row) for row in source_rows],
            "last_agent_event_at": last_agent_event,
            "redaction_labels": [
                "[REDACTED_OPENAI_KEY]",
                "[REDACTED_GITHUB_TOKEN]",
                "[REDACTED_SLACK_TOKEN]",
                "[REDACTED_SECRET]",
                "[REDACTED_EMAIL]",
                "[REDACTED_NUMBER]",
            ],
        }

    def audit_log(self, user_id: str, limit: int = 100) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            rows = conn.execute(
                """
                SELECT *
                FROM memory_events
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (user_id, limit),
            ).fetchall()
        events: list[dict[str, Any]] = []
        for row in rows:
            metadata = self._json_or_empty(row["metadata_json"])
            events.append(
                {
                    "id": row["id"],
                    "object_id": row["object_id"],
                    "object_type": row["object_type"],
                    "event_type": row["event_type"],
                    "metadata": metadata,
                    "metadata_text": self._metadata_summary(metadata),
                    "created_at": row["created_at"],
                }
            )
        return events

    def _support_event_summary(self, event: dict[str, Any]) -> dict[str, Any]:
        metadata = event.get("metadata") if isinstance(event.get("metadata"), dict) else {}
        safe_metadata: dict[str, Any] = {}
        for key in (
            "tool",
            "success",
            "content_chars",
            "memory_count",
            "size_bytes",
            "format",
            "indexed_memories",
            "vector_indexed_memories",
            "token_id",
            "token_label",
            "token_audience",
            "token_admin",
            "token_scopes",
        ):
            if key in metadata:
                safe_metadata[key] = self._support_safe_payload(metadata[key], key)
        actions = metadata.get("actions")
        if isinstance(actions, list):
            safe_metadata["actions"] = [
                {
                    "name": item.get("name"),
                    "rows": item.get("rows"),
                }
                for item in actions
                if isinstance(item, dict)
            ][:12]
        return {
            "id": event.get("id"),
            "object_type": event.get("object_type"),
            "event_type": event.get("event_type"),
            "created_at": event.get("created_at"),
            "metadata_keys": sorted(metadata.keys()),
            "safe_metadata": safe_metadata,
        }

    def _support_safe_payload(self, value: Any, key: str = "") -> Any:
        if key in SUPPORT_OMITTED_KEYS:
            return "[omitted from support bundle]"
        if isinstance(value, dict):
            safe: dict[str, Any] = {}
            for child_key, child_value in value.items():
                if child_key in SUPPORT_OMITTED_KEYS:
                    safe[child_key] = "[omitted from support bundle]"
                else:
                    safe[child_key] = self._support_safe_payload(child_value, child_key)
            return safe
        if isinstance(value, list):
            return [self._support_safe_payload(item, key) for item in value[:200]]
        if isinstance(value, str):
            text = self._redact_text(value)
            if key in SUPPORT_PATH_KEYS or text.startswith("/Users/"):
                text = self._support_safe_path(text)
            if len(text) > 600:
                return text[:600] + "...[truncated]"
            return text
        return value

    def _support_safe_path(self, value: str) -> str:
        home = str(Path.home())
        if value == home:
            return "~"
        if value.startswith(home + "/"):
            return "~/" + value[len(home) + 1:]
        return value

    def require_agent_access(self, user_id: str, capability: str) -> None:
        user_settings = self.settings(user_id)
        labels = {
            "read": "Agent memory reads are disabled in Cortex Trust controls.",
            "write": "Agent memory writes are disabled in Cortex Trust controls.",
            "export": "Agent context exports are disabled in Cortex Trust controls.",
            "maintenance": "Agent maintenance actions are disabled in Cortex Trust controls.",
            "destructive": "Agent destructive actions are disabled in Cortex Trust controls.",
        }
        setting_by_capability = {
            "read": "allow_agent_reads",
            "write": "allow_agent_writes",
            "export": "allow_agent_exports",
            "maintenance": "allow_agent_maintenance",
            "destructive": "allow_agent_destructive_actions",
        }
        key = setting_by_capability.get(capability)
        if key and not user_settings[key]:
            raise PermissionError(labels.get(capability, "Agent action is disabled in Cortex Trust controls."))

    def agent_payload(self, user_id: str, value: Any) -> Any:
        return self._redact_payload(value) if self.settings(user_id)["redact_sensitive_context"] else value

    def record_agent_event(
        self,
        user_id: str,
        tool_name: str,
        args: dict[str, Any],
        *,
        success: bool,
        error: str | None = None,
        token: dict[str, Any] | None = None,
    ) -> None:
        metadata: dict[str, Any] = {
            "tool": tool_name,
            "success": success,
            "arg_keys": sorted(args.keys()),
        }
        if token:
            metadata["token_id"] = token.get("token_id")
            metadata["token_label"] = token.get("label")
            metadata["token_audience"] = token.get("audience", "mcp")
            metadata["token_admin"] = bool(token.get("admin"))
            metadata["token_scopes"] = token.get("scopes", [])
        content = args.get("content")
        if isinstance(content, str):
            metadata["content_chars"] = len(content)
        query = args.get("query")
        if isinstance(query, str):
            metadata["query"] = query[:120]
        if error:
            metadata["error"] = error[:240]
        with connect(self.db_path) as conn:
            self._event(conn, user_id, f"mcp:{tool_name}", "agent", "tool_call", metadata)

    def _enqueue_job(
        self,
        conn,
        *,
        user_id: str,
        job_type: str,
        object_type: str,
        object_id: str,
        unique_key: str,
        payload: dict[str, Any],
        priority: int = 100,
        run_at: str | None = None,
        max_attempts: int = 3,
    ) -> dict[str, Any]:
        timestamp = now_iso()
        job_id = stable_id("job_", unique_key)
        conn.execute(
            """
            INSERT OR IGNORE INTO memory_jobs
            (id, user_id, job_type, object_type, object_id, status, priority, run_at, attempts, max_attempts, unique_key, payload_json, result_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, 'queued', ?, ?, 0, ?, ?, ?, '{}', ?, ?)
            """,
            (
                job_id,
                user_id,
                job_type,
                object_type,
                object_id,
                priority,
                run_at or timestamp,
                max_attempts,
                unique_key,
                json.dumps(payload),
                timestamp,
                timestamp,
            ),
        )
        row = conn.execute("SELECT * FROM memory_jobs WHERE unique_key = ?", (unique_key,)).fetchone()
        return self._job_from_row(row)

    def _claim_next_job(self, user_id: str, worker_id: str) -> dict[str, Any] | None:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            conn.execute("BEGIN IMMEDIATE")
            row = conn.execute(
                """
                SELECT *
                FROM memory_jobs
                WHERE user_id = ?
                  AND status = 'queued'
                  AND run_at <= ?
                ORDER BY priority ASC, created_at ASC
                LIMIT 1
                """,
                (user_id, timestamp),
            ).fetchone()
            if not row:
                return None
            conn.execute(
                """
                UPDATE memory_jobs
                SET status = 'running',
                    attempts = attempts + 1,
                    locked_by = ?,
                    locked_until = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (worker_id, timestamp, timestamp, row["id"]),
            )
            claimed = conn.execute("SELECT * FROM memory_jobs WHERE id = ?", (row["id"],)).fetchone()
        return self._job_from_row(claimed)

    def _run_job(self, job: dict[str, Any], worker_id: str) -> dict[str, Any]:
        try:
            if job["job_type"] == "extract_capture":
                result = self._process_extract_capture_job(job)
            elif job["job_type"] == "embed_memory":
                result = self._process_embed_memory_job(job)
            else:
                raise ValueError(f"Unsupported memory job type: {job['job_type']}")
            completed = self._complete_job(job["id"], result)
            if job["job_type"] == "embed_memory" and result.get("capture_id"):
                self._refresh_capture_embedding_state(
                    job["user_id"],
                    str(result["capture_id"]),
                    last_job_id=job["id"],
                )
            return completed
        except Exception as exc:
            return self._fail_job(job, str(exc))

    def _process_extract_capture_job(self, job: dict[str, Any]) -> dict[str, Any]:
        payload = job.get("payload") or {}
        capture_id = payload["capture_id"]
        user_id = job["user_id"]
        started_at = now_iso()
        with connect(self.db_path) as conn:
            capture = conn.execute(
                "SELECT * FROM captures WHERE user_id = ? AND id = ?",
                (user_id, capture_id),
            ).fetchone()
        if not capture:
            return {
                "capture_id": capture_id,
                "skipped": True,
                "reason": "capture_missing_or_deleted",
                "completed_at": started_at,
            }
        with connect(self.db_path) as conn:
            conn.execute(
                """
                UPDATE capture_processing_state
                SET extraction_status = 'running',
                    started_at = COALESCE(started_at, ?),
                    updated_at = ?,
                    last_job_id = ?
                WHERE user_id = ? AND capture_id = ?
                """,
                (started_at, started_at, job["id"], user_id, capture_id),
            )
        content = capture["raw_text"]
        source = capture["source"]
        extracted = extract_context(content, source)
        extracted["_timestamp"] = capture["captured_at"] or payload.get("captured_at") or started_at
        saved = self.save_capture(
            user_id=user_id,
            content=content,
            source=source,
            source_url=capture["source_url"],
            title=capture["title"],
            extracted=extracted,
        )
        completed_at = now_iso()
        memory_count = len(saved.get("memories", []))
        task_count = len(saved.get("tasks", []))
        entity_count = len(saved.get("entities", []))
        with connect(self.db_path) as conn:
            embedding_state = self._capture_embedding_status(conn, user_id, capture_id)
            conn.execute(
                """
                INSERT OR REPLACE INTO capture_processing_state
                (capture_id, user_id, ingest_status, extraction_status, embedding_status, memory_count, task_count, entity_count, last_job_id, last_error, queued_at, started_at, completed_at, updated_at)
                VALUES (?, ?, 'materialized', 'succeeded', ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?)
                """,
                (
                    capture_id,
                    user_id,
                    embedding_state,
                    memory_count,
                    task_count,
                    entity_count,
                    job["id"],
                    payload.get("captured_at") or started_at,
                    started_at,
                    completed_at,
                    completed_at,
                ),
            )
            self._event(
                conn,
                user_id,
                capture_id,
                "capture",
                "processed",
                {"job_id": job["id"], "memories": memory_count, "tasks": task_count, "entities": entity_count},
            )
        return {
            "capture_id": capture_id,
            "memories": memory_count,
            "tasks": task_count,
            "entities": entity_count,
            "completed_at": completed_at,
        }

    def _process_embed_memory_job(self, job: dict[str, Any]) -> dict[str, Any]:
        payload = job.get("payload") or {}
        memory_id = str(payload.get("memory_id") or job["object_id"])
        user_id = job["user_id"]
        started_at = now_iso()
        with connect(self.db_path) as conn:
            row = conn.execute(
                """
                SELECT id, capture_id, user_id, kind, layer, content, summary, source, topics_json, status, captured_at
                FROM memories
                WHERE user_id = ? AND id = ?
                """,
                (user_id, memory_id),
            ).fetchone()
            if not row:
                return {
                    "memory_id": memory_id,
                    "capture_id": payload.get("capture_id"),
                    "skipped": True,
                    "reason": "memory_missing_or_deleted",
                    "completed_at": started_at,
                }
            capture_id = row["capture_id"]
            if row["status"] != "active":
                self._delete_memory_vector(conn, memory_id)
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "memory_not_active",
                    "completed_at": started_at,
                }
            if not self._vector_ready(conn):
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "vector_not_available",
                    "vector_available": False,
                    "embedding": embedding_status(),
                    "completed_at": started_at,
                }
            topics = self._json_list(row["topics_json"])
            layer = memory_layer(row["kind"], row["layer"])
            text = embedding_source_text(row["content"], row["summary"], row["source"], layer, " ".join(topics))
            if not text:
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "empty_embedding_text",
                    "completed_at": started_at,
                }
            text_hash = embedding_hash(text)
            status = embedding_status()
            if self._memory_vector_current(conn, memory_id, status["model"], text_hash):
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "vector_already_current",
                    "text_hash": text_hash,
                    "embedding_model": status["model"],
                    "completed_at": started_at,
                }

        embedding = embed_text_result(text)
        vector = embedding_json(embedding.vector)
        completed_at = now_iso()
        with connect(self.db_path) as conn:
            if not self._vector_ready(conn):
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "vector_not_available",
                    "vector_available": False,
                    "embedding": embedding_status(),
                    "completed_at": completed_at,
                }
            still_active = conn.execute(
                "SELECT id FROM memories WHERE user_id = ? AND id = ? AND status = 'active'",
                (user_id, memory_id),
            ).fetchone()
            if not still_active:
                self._delete_memory_vector(conn, memory_id)
                return {
                    "memory_id": memory_id,
                    "capture_id": capture_id,
                    "skipped": True,
                    "reason": "memory_deleted_before_write",
                    "completed_at": completed_at,
                }
            self._write_memory_vector(
                conn,
                memory_id=memory_id,
                user_id=user_id,
                embedding_model=embedding.model,
                text_hash=text_hash,
                vector=vector,
                timestamp=completed_at,
            )
            self._event(
                conn,
                user_id,
                memory_id,
                "memory",
                "vector_indexed",
                {"capture_id": capture_id, "embedding_model": embedding.model, "provider": embedding.provider},
            )
        return {
            "memory_id": memory_id,
            "capture_id": capture_id,
            "text_hash": text_hash,
            "embedding_model": embedding.model,
            "provider": embedding.provider,
            "dimensions": embedding.dimensions,
            "completed_at": completed_at,
        }

    def _complete_job(self, job_id: str, result: dict[str, Any]) -> dict[str, Any]:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            conn.execute(
                """
                UPDATE memory_jobs
                SET status = 'succeeded',
                    result_json = ?,
                    last_error = NULL,
                    locked_by = NULL,
                    locked_until = NULL,
                    completed_at = ?,
                    updated_at = ?
                WHERE id = ?
                """,
                (json.dumps(result), timestamp, timestamp, job_id),
            )
            row = conn.execute("SELECT * FROM memory_jobs WHERE id = ?", (job_id,)).fetchone()
        return self._job_from_row(row)

    def _fail_job(self, job: dict[str, Any], error: str) -> dict[str, Any]:
        timestamp = now_iso()
        final_status = "failed" if int(job.get("attempts", 0)) >= int(job.get("max_attempts", 3)) else "queued"
        with connect(self.db_path) as conn:
            conn.execute(
                """
                UPDATE memory_jobs
                SET status = ?,
                    last_error = ?,
                    locked_by = NULL,
                    locked_until = NULL,
                    updated_at = ?
                WHERE id = ?
                """,
                (final_status, error[:500], timestamp, job["id"]),
            )
            if job.get("object_type") == "capture":
                conn.execute(
                    """
                    UPDATE capture_processing_state
                    SET extraction_status = ?,
                        last_error = ?,
                        updated_at = ?,
                        last_job_id = ?
                    WHERE user_id = ? AND capture_id = ?
                    """,
                    (final_status, error[:500], timestamp, job["id"], job["user_id"], job["object_id"]),
                )
            row = conn.execute("SELECT * FROM memory_jobs WHERE id = ?", (job["id"],)).fetchone()
        if job.get("job_type") == "embed_memory":
            payload = job.get("payload") or {}
            capture_id = payload.get("capture_id")
            if capture_id:
                self._refresh_capture_embedding_state(
                    job["user_id"],
                    str(capture_id),
                    last_job_id=job["id"],
                    last_error=error[:500],
                )
        return self._job_from_row(row)

    def _refresh_capture_embedding_state(
        self,
        user_id: str,
        capture_id: str,
        *,
        last_job_id: str | None = None,
        last_error: str | None = None,
    ) -> None:
        timestamp = now_iso()
        with connect(self.db_path) as conn:
            capture = conn.execute(
                "SELECT id, captured_at FROM captures WHERE user_id = ? AND id = ?",
                (user_id, capture_id),
            ).fetchone()
            if not capture:
                return
            memory_count = conn.execute(
                "SELECT COUNT(*) FROM memories WHERE user_id = ? AND capture_id = ? AND status = 'active'",
                (user_id, capture_id),
            ).fetchone()[0]
            status = self._capture_embedding_status(conn, user_id, capture_id)
            conn.execute(
                """
                INSERT OR IGNORE INTO capture_processing_state
                (capture_id, user_id, ingest_status, extraction_status, embedding_status, memory_count, task_count, entity_count, last_job_id, last_error, queued_at, completed_at, updated_at)
                VALUES (?, ?, 'materialized', 'succeeded', ?, ?, 0, 0, ?, ?, ?, ?, ?)
                """,
                (
                    capture_id,
                    user_id,
                    status,
                    memory_count,
                    last_job_id,
                    last_error,
                    capture["captured_at"] or timestamp,
                    capture["captured_at"] or timestamp,
                    timestamp,
                ),
            )
            conn.execute(
                """
                UPDATE capture_processing_state
                SET embedding_status = ?,
                    memory_count = ?,
                    last_job_id = COALESCE(?, last_job_id),
                    last_error = ?,
                    updated_at = ?
                WHERE user_id = ? AND capture_id = ?
                """,
                (status, memory_count, last_job_id, last_error, timestamp, user_id, capture_id),
            )

    def _capture_embedding_status(self, conn, user_id: str, capture_id: str) -> str:
        active_count = conn.execute(
            "SELECT COUNT(*) FROM memories WHERE user_id = ? AND capture_id = ? AND status = 'active'",
            (user_id, capture_id),
        ).fetchone()[0]
        if not active_count:
            return "not_needed"
        if not self._vector_ready(conn):
            return "not_available"
        vector_count = conn.execute(
            """
            SELECT COUNT(*)
            FROM memory_vec_map map
            JOIN memories m ON m.id = map.memory_id
            WHERE m.user_id = ?
              AND m.capture_id = ?
              AND m.status = 'active'
            """,
            (user_id, capture_id),
        ).fetchone()[0]
        if vector_count >= active_count:
            return "available"
        job_counts = conn.execute(
            """
            SELECT
              SUM(CASE WHEN j.status IN ('queued', 'running') THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN j.status = 'failed' THEN 1 ELSE 0 END) AS failed
            FROM memory_jobs j
            JOIN memories m ON m.id = j.object_id
            WHERE j.user_id = ?
              AND j.job_type = 'embed_memory'
              AND j.object_type = 'memory'
              AND m.capture_id = ?
            """,
            (user_id, capture_id),
        ).fetchone()
        pending = int(job_counts["pending"] or 0)
        failed = int(job_counts["failed"] or 0)
        if pending:
            return "queued"
        if failed:
            return "failed"
        return "queued"

    def _job_from_row(self, row) -> dict[str, Any]:
        payload = self._json_or_empty(row["payload_json"])
        result = self._json_or_empty(row["result_json"])
        return {
            "id": row["id"],
            "user_id": row["user_id"],
            "job_type": row["job_type"],
            "object_type": row["object_type"],
            "object_id": row["object_id"],
            "status": row["status"],
            "priority": row["priority"],
            "run_at": row["run_at"],
            "attempts": row["attempts"],
            "max_attempts": row["max_attempts"],
            "locked_by": row["locked_by"],
            "locked_until": row["locked_until"],
            "unique_key": row["unique_key"],
            "payload": payload,
            "result": result,
            "last_error": row["last_error"],
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
            "completed_at": row["completed_at"],
        }

    def _token_hash(self, token: str, salt: str) -> str:
        return hashlib.sha256(f"{salt}:{token}".encode("utf-8")).hexdigest()

    def _json_list(self, value: str | None) -> list[str]:
        try:
            parsed = json.loads(value or "[]")
        except json.JSONDecodeError:
            return []
        if not isinstance(parsed, list):
            return []
        return [str(item) for item in parsed]

    def _save_memory(self, conn, capture_id: str, user_id: str, record: dict[str, Any], source: str, source_url: str | None, captured_at: str, raw_text: str) -> dict[str, Any]:
        memory_id = record["id"]
        kind = record.get("kind", "observation")
        layer = memory_layer(kind, record.get("layer"))
        topics = record.get("topics", [])
        entity_ids = record.get("entity_ids", [])
        conn.execute(
            """
            INSERT OR REPLACE INTO memories
            (id, capture_id, user_id, kind, layer, content, summary, source, source_url, confidence, importance, status, topics_json, entity_ids_json, occurred_at, captured_at, updated_at, raw_excerpt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, ?, ?, ?)
            """,
            (
                memory_id,
                capture_id,
                user_id,
                kind,
                layer,
                record.get("content", ""),
                record.get("summary", ""),
                source,
                source_url,
                record.get("confidence", "confirmed"),
                int(record.get("importance", 3)),
                json.dumps(topics),
                json.dumps(entity_ids),
                record.get("occurred_at"),
                captured_at,
                captured_at,
                raw_text[:500],
            ),
        )
        conn.execute("DELETE FROM memory_entities WHERE memory_id = ?", (memory_id,))
        conn.execute("DELETE FROM memory_topics WHERE memory_id = ?", (memory_id,))
        for entity_id in entity_ids:
            conn.execute(
                "INSERT OR REPLACE INTO memory_entities(memory_id, entity_id, user_id, created_at) VALUES (?, ?, ?, ?)",
                (memory_id, entity_id, user_id, captured_at),
            )
        for topic in topics:
            conn.execute(
                "INSERT OR REPLACE INTO memory_topics(memory_id, topic, user_id, created_at) VALUES (?, ?, ?, ?)",
                (memory_id, topic, user_id, captured_at),
            )
        conn.execute("DELETE FROM memory_fts WHERE memory_id = ?", (memory_id,))
        conn.execute(
            "INSERT INTO memory_fts(memory_id, content, summary, source, topics) VALUES (?, ?, ?, ?, ?)",
            (memory_id, record.get("content", ""), record.get("summary", ""), source, " ".join(topics)),
        )
        self._enqueue_embed_memory_job(
            conn,
            memory_id=memory_id,
            capture_id=capture_id,
            user_id=user_id,
            content=record.get("content", ""),
            summary=record.get("summary", ""),
            source=source,
            layer=layer,
            topics=topics,
            captured_at=captured_at,
        )
        return {
            "id": memory_id,
            "capture_id": capture_id,
            "user_id": user_id,
            "kind": kind,
            "layer": layer,
            "content": record.get("content", ""),
            "summary": record.get("summary", ""),
            "source": source,
            "source_url": source_url,
            "confidence": record.get("confidence", "confirmed"),
            "importance": int(record.get("importance", 3)),
            "status": "active",
            "topics": topics,
            "entity_ids": entity_ids,
            "occurred_at": record.get("occurred_at"),
            "captured_at": captured_at,
            "updated_at": captured_at,
            "raw_excerpt": raw_text[:500],
        }

    def _vector_ready(self, conn) -> bool:
        if embedding_status()["dimensions"] != VECTOR_DIMENSIONS:
            return False
        status = sqlite_vec_status(conn)
        if not status["available"]:
            return False
        try:
            conn.execute("SELECT 1 FROM memory_vec LIMIT 1")
            return True
        except sqlite3.Error:
            return False

    def _vector_search(self, conn, user_id: str, query: str, limit: int, kind: str | None, layer: str | None, user_settings: dict[str, Any]) -> list[Any]:
        if not self._vector_ready(conn):
            return []
        filters, params = self._memory_filters(user_id, user_settings, alias="m", kind=kind, layer=layer)
        where = " AND ".join(filters)
        try:
            vector = embedding_json(embed_text(query))
        except Exception:
            return []
        try:
            return conn.execute(
                f"""
                SELECT m.*, memory_vec.distance AS vector_distance
                FROM memory_vec
                JOIN memory_vec_map map ON map.vec_rowid = memory_vec.rowid
                JOIN memories m ON m.id = map.memory_id
                WHERE memory_vec.embedding MATCH ? AND {where}
                ORDER BY memory_vec.distance ASC, m.importance DESC, m.captured_at DESC
                LIMIT ?
                """,
                [vector, *params, limit],
            ).fetchall()
        except sqlite3.Error:
            return []

    def _fuse_search_rows(self, query: str, fts_rows: list[Any], vector_rows: list[Any], limit: int) -> list[Any]:
        ranked: dict[str, dict[str, Any]] = {}
        for index, row in enumerate(fts_rows):
            entry = ranked.setdefault(row["id"], {"row": row, "score": 0.0})
            entry["score"] += 0.6 / (60 + index)
        for index, row in enumerate(vector_rows):
            entry = ranked.setdefault(row["id"], {"row": row, "score": 0.0})
            entry["score"] += 0.4 / (60 + index)
        layer_boosts = query_layer_boosts(query)
        for entry in ranked.values():
            entry["score"] += self._layer_boost(entry["row"], layer_boosts)
        return [item["row"] for item in sorted(ranked.values(), key=lambda item: item["score"], reverse=True)[:limit]]

    def _rank_rows_with_layer_boosts(self, query: str, rows: list[Any], limit: int) -> list[Any]:
        layer_boosts = query_layer_boosts(query)
        ranked = [
            {"row": row, "score": (0.2 / (60 + index)) + self._layer_boost(row, layer_boosts)}
            for index, row in enumerate(rows)
        ]
        return [item["row"] for item in sorted(ranked, key=lambda item: item["score"], reverse=True)[:limit]]

    def _layer_boost(self, row: Any, layer_boosts: dict[str, float]) -> float:
        if not layer_boosts:
            return 0.0
        keys = set(row.keys())
        layer = memory_layer(row["kind"], row["layer"] if "layer" in keys else None)
        return layer_boosts.get(layer, 0.0)

    def _enqueue_embed_memory_job(
        self,
        conn,
        *,
        memory_id: str,
        capture_id: str | None,
        user_id: str,
        content: str,
        summary: str | None,
        source: str,
        layer: str,
        topics: list[str],
        captured_at: str,
        priority: int = 80,
    ) -> dict[str, Any] | None:
        if not self._vector_ready(conn):
            return None
        text = embedding_source_text(content, summary, source, layer, " ".join(topics))
        if not text:
            return None
        text_hash = embedding_hash(text)
        status = embedding_status()
        if self._memory_vector_current(conn, memory_id, status["model"], text_hash):
            return None
        unique_key = f"embed_memory:{memory_id}:{status['model']}:{status['dimensions']}:{text_hash}"
        payload = {
            "memory_id": memory_id,
            "capture_id": capture_id,
            "text_hash": text_hash,
            "embedding_model": status["model"],
            "embedding_provider": status["provider"],
            "embedding_dimensions": status["dimensions"],
            "captured_at": captured_at,
        }
        job = self._enqueue_job(
            conn,
            user_id=user_id,
            job_type="embed_memory",
            object_type="memory",
            object_id=memory_id,
            unique_key=unique_key,
            payload=payload,
            priority=priority,
        )
        if job["status"] != "queued":
            timestamp = now_iso()
            conn.execute(
                """
                UPDATE memory_jobs
                SET status = 'queued',
                    attempts = 0,
                    run_at = ?,
                    locked_by = NULL,
                    locked_until = NULL,
                    payload_json = ?,
                    result_json = '{}',
                    last_error = NULL,
                    completed_at = NULL,
                    updated_at = ?
                WHERE id = ?
                """,
                (timestamp, json.dumps(payload), timestamp, job["id"]),
            )
            row = conn.execute("SELECT * FROM memory_jobs WHERE id = ?", (job["id"],)).fetchone()
            job = self._job_from_row(row)
        return job

    def _memory_vector_current(self, conn, memory_id: str, embedding_model: str, text_hash: str) -> bool:
        try:
            row = conn.execute(
                "SELECT vec_rowid, embedding_model, text_hash FROM memory_vec_map WHERE memory_id = ?",
                (memory_id,),
            ).fetchone()
            if not row or row["embedding_model"] != embedding_model or row["text_hash"] != text_hash:
                return False
            return conn.execute("SELECT 1 FROM memory_vec WHERE rowid = ?", (row["vec_rowid"],)).fetchone() is not None
        except sqlite3.Error:
            return False

    def _write_memory_vector(
        self,
        conn,
        *,
        memory_id: str,
        user_id: str,
        embedding_model: str,
        text_hash: str,
        vector: str,
        timestamp: str,
    ) -> None:
        existing = conn.execute("SELECT vec_rowid FROM memory_vec_map WHERE memory_id = ?", (memory_id,)).fetchone()
        if existing:
            vec_rowid = existing["vec_rowid"]
            conn.execute("DELETE FROM memory_vec WHERE rowid = ?", (vec_rowid,))
            conn.execute(
                "UPDATE memory_vec_map SET user_id = ?, embedding_model = ?, text_hash = ?, updated_at = ? WHERE vec_rowid = ?",
                (user_id, embedding_model, text_hash, timestamp, vec_rowid),
            )
        else:
            cursor = conn.execute(
                """
                INSERT INTO memory_vec_map(memory_id, user_id, embedding_model, text_hash, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (memory_id, user_id, embedding_model, text_hash, timestamp, timestamp),
            )
            vec_rowid = cursor.lastrowid
        conn.execute("INSERT INTO memory_vec(rowid, embedding) VALUES (?, ?)", (vec_rowid, vector))

    def _index_memory_vector(self, conn, *, memory_id: str, user_id: str, content: str, summary: str | None, source: str, layer: str, topics: list[str], captured_at: str) -> bool:
        if not self._vector_ready(conn):
            return False
        text = embedding_source_text(content, summary, source, layer, " ".join(topics))
        if not text:
            return False
        text_hash = embedding_hash(text)
        embedding = embed_text_result(text)
        vector = embedding_json(embedding.vector)
        try:
            self._write_memory_vector(
                conn,
                memory_id=memory_id,
                user_id=user_id,
                embedding_model=embedding.model,
                text_hash=text_hash,
                vector=vector,
                timestamp=captured_at,
            )
            return True
        except sqlite3.Error:
            return False

    def _delete_memory_vector(self, conn, memory_id: str) -> None:
        if not self._vector_ready(conn):
            return
        try:
            row = conn.execute("SELECT vec_rowid FROM memory_vec_map WHERE memory_id = ?", (memory_id,)).fetchone()
            if row:
                conn.execute("DELETE FROM memory_vec WHERE rowid = ?", (row["vec_rowid"],))
                conn.execute("DELETE FROM memory_vec_map WHERE vec_rowid = ?", (row["vec_rowid"],))
        except sqlite3.Error:
            return

    def _purge_edges_for_objects(self, conn, user_id: str, object_ids: list[str]) -> list[str]:
        ids = [value for value in dict.fromkeys(object_ids) if value]
        if not ids:
            return []
        placeholders = ",".join("?" for _ in ids)
        rows = conn.execute(
            f"""
            SELECT id
            FROM graph_edges
            WHERE user_id = ?
              AND (
                source_id IN ({placeholders})
                OR target_id IN ({placeholders})
                OR evidence_id IN ({placeholders})
              )
            """,
            [user_id, *ids, *ids, *ids],
        ).fetchall()
        edge_ids = [row["id"] for row in rows]
        if edge_ids:
            edge_placeholders = ",".join("?" for _ in edge_ids)
            conn.execute(f"DELETE FROM graph_edges WHERE user_id = ? AND id IN ({edge_placeholders})", [user_id, *edge_ids])
        return edge_ids

    def _purge_memory_rows(self, conn, user_id: str, memory_ids: list[str]) -> None:
        ids = [value for value in dict.fromkeys(memory_ids) if value]
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        for memory_id in ids:
            self._delete_memory_vector(conn, memory_id)
        conn.execute(f"DELETE FROM memory_jobs WHERE user_id = ? AND object_type = 'memory' AND object_id IN ({placeholders})", [user_id, *ids])
        conn.execute(f"DELETE FROM memory_fts WHERE memory_id IN ({placeholders})", ids)
        conn.execute(f"DELETE FROM memory_entities WHERE user_id = ? AND memory_id IN ({placeholders})", [user_id, *ids])
        conn.execute(f"DELETE FROM memory_topics WHERE user_id = ? AND memory_id IN ({placeholders})", [user_id, *ids])
        conn.execute(f"DELETE FROM memories WHERE user_id = ? AND id IN ({placeholders})", [user_id, *ids])

    def _purge_task_rows(self, conn, user_id: str, task_ids: list[str]) -> None:
        ids = [value for value in dict.fromkeys(task_ids) if value]
        if not ids:
            return
        placeholders = ",".join("?" for _ in ids)
        conn.execute(f"DELETE FROM task_entities WHERE user_id = ? AND task_id IN ({placeholders})", [user_id, *ids])
        conn.execute(f"DELETE FROM task_topics WHERE user_id = ? AND task_id IN ({placeholders})", [user_id, *ids])
        conn.execute(f"DELETE FROM tasks WHERE user_id = ? AND id IN ({placeholders})", [user_id, *ids])

    def _clear_user_vectors(self, conn, user_id: str) -> None:
        if not self._vector_ready(conn):
            return
        try:
            rows = conn.execute("SELECT vec_rowid FROM memory_vec_map WHERE user_id = ?", (user_id,)).fetchall()
            for row in rows:
                conn.execute("DELETE FROM memory_vec WHERE rowid = ?", (row["vec_rowid"],))
            conn.execute("DELETE FROM memory_vec_map WHERE user_id = ?", (user_id,))
        except sqlite3.Error:
            return

    def _vector_count(self, conn, user_id: str) -> int:
        if not self._vector_ready(conn):
            return 0
        try:
            return conn.execute("SELECT COUNT(*) FROM memory_vec_map WHERE user_id = ?", (user_id,)).fetchone()[0]
        except sqlite3.Error:
            return 0

    def _settings(self, conn, user_id: str) -> dict[str, Any]:
        settings = dict(DEFAULT_USER_SETTINGS)
        vault_settings = self.vault.read_settings(user_id)
        if vault_settings:
            settings.update({key: value for key, value in vault_settings.items() if key in settings})
        try:
            rows = conn.execute("SELECT key, value_json FROM user_settings WHERE user_id = ?", (user_id,)).fetchall()
        except sqlite3.Error:
            return settings
        for row in rows:
            if row["key"] not in settings:
                continue
            try:
                settings[row["key"]] = json.loads(row["value_json"])
            except json.JSONDecodeError:
                continue
        settings["review_new_captures"] = bool(settings["review_new_captures"])
        settings["allow_pending_in_context"] = bool(settings["allow_pending_in_context"])
        settings["allow_agent_reads"] = bool(settings["allow_agent_reads"])
        settings["allow_agent_writes"] = bool(settings["allow_agent_writes"])
        settings["allow_agent_exports"] = bool(settings["allow_agent_exports"])
        settings["allow_agent_maintenance"] = bool(settings["allow_agent_maintenance"])
        settings["allow_agent_destructive_actions"] = bool(settings["allow_agent_destructive_actions"])
        settings["redact_sensitive_context"] = bool(settings["redact_sensitive_context"])
        try:
            settings["context_pack_limit"] = min(50, max(4, int(settings["context_pack_limit"])))
        except (TypeError, ValueError):
            settings["context_pack_limit"] = int(DEFAULT_USER_SETTINGS["context_pack_limit"])
        return settings

    def _redact_text(self, value: str, enabled: bool = True) -> str:
        if not enabled:
            return value
        redacted = value
        for pattern, replacement in SENSITIVE_PATTERNS:
            redacted = pattern.sub(replacement, redacted)
        return redacted

    def _redact_payload(self, value: Any) -> Any:
        if isinstance(value, str):
            return self._redact_text(value)
        if isinstance(value, list):
            return [self._redact_payload(item) for item in value]
        if isinstance(value, tuple):
            return [self._redact_payload(item) for item in value]
        if isinstance(value, dict):
            return {key: self._redact_payload(item) for key, item in value.items()}
        return value

    def _json_or_empty(self, value: str | None) -> dict[str, Any]:
        try:
            payload = json.loads(value or "{}")
        except json.JSONDecodeError:
            return {}
        return payload if isinstance(payload, dict) else {}

    def _metadata_summary(self, metadata: dict[str, Any]) -> str:
        if not metadata:
            return ""
        pieces: list[str] = []
        if "tool" in metadata:
            pieces.append(f"tool={metadata['tool']}")
        if "source" in metadata:
            pieces.append(f"source={metadata['source']}")
        if "title" in metadata and metadata["title"]:
            pieces.append(f"title={metadata['title']}")
        if "query" in metadata and metadata["query"]:
            pieces.append(f"query={metadata['query']}")
        if "success" in metadata:
            pieces.append(f"success={metadata['success']}")
        if "content_chars" in metadata:
            pieces.append(f"chars={metadata['content_chars']}")
        if "memory_count" in metadata:
            pieces.append(f"memories={metadata['memory_count']}")
        if "error" in metadata:
            pieces.append(f"error={metadata['error']}")
        return ", ".join(str(piece) for piece in pieces[:6])

    def _memory_filters(self, user_id: str, user_settings: dict[str, Any], *, alias: str = "m", kind: str | None = None, layer: str | None = None) -> tuple[list[str], list[Any]]:
        filters = [f"{alias}.user_id = ?", f"{alias}.status = 'active'"]
        params: list[Any] = [user_id]
        if kind:
            filters.append(f"{alias}.kind = ?")
            params.append(kind)
        if layer:
            filters.append(f"{alias}.layer = ?")
            params.append(memory_layer(None, layer))
        if not user_settings["allow_pending_in_context"]:
            filters.append(
                f"({alias}.capture_id IS NULL OR EXISTS (SELECT 1 FROM captures c WHERE c.id = {alias}.capture_id AND c.user_id = {alias}.user_id AND c.review_status = 'approved'))"
            )
        return filters, params

    def _save_task(self, conn, capture_id: str, user_id: str, task: dict[str, Any], captured_at: str) -> dict[str, Any]:
        task_id = task["id"]
        topics = task.get("topics", [])
        entity_ids = task.get("entity_ids", [])
        conn.execute(
            """
            INSERT OR REPLACE INTO tasks
            (id, capture_id, user_id, kind, content, status, importance, topics_json, entity_ids_json, captured_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (task_id, capture_id, user_id, task.get("kind", "action"), task.get("content", ""), task.get("status", "open"), int(task.get("importance", 3)), json.dumps(topics), json.dumps(entity_ids), captured_at),
        )
        conn.execute("DELETE FROM task_entities WHERE task_id = ?", (task_id,))
        conn.execute("DELETE FROM task_topics WHERE task_id = ?", (task_id,))
        for entity_id in entity_ids:
            conn.execute(
                "INSERT OR REPLACE INTO task_entities(task_id, entity_id, user_id, created_at) VALUES (?, ?, ?, ?)",
                (task_id, entity_id, user_id, captured_at),
            )
        for topic in topics:
            conn.execute(
                "INSERT OR REPLACE INTO task_topics(task_id, topic, user_id, created_at) VALUES (?, ?, ?, ?)",
                (task_id, topic, user_id, captured_at),
            )
        return {
            "id": task_id,
            "capture_id": capture_id,
            "user_id": user_id,
            "kind": task.get("kind", "action"),
            "content": task.get("content", ""),
            "status": task.get("status", "open"),
            "importance": int(task.get("importance", 3)),
            "topics": topics,
            "entity_ids": entity_ids,
            "captured_at": captured_at,
        }

    def _save_entity(self, conn, user_id: str, entity: dict[str, Any], captured_at: str) -> dict[str, Any]:
        entity_id = entity["id"]
        existing = conn.execute("SELECT id FROM entities WHERE user_id = ? AND id = ?", (user_id, entity_id)).fetchone()
        if existing:
            conn.execute("UPDATE entities SET context = ?, last_seen = ? WHERE user_id = ? AND id = ?", (entity.get("context", ""), captured_at, user_id, entity_id))
        else:
            conn.execute(
                "INSERT INTO entities (id, user_id, kind, name, aliases_json, context, first_seen, last_seen) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (entity_id, user_id, entity.get("kind", "person"), entity.get("name", entity_id), json.dumps(entity.get("aliases", [])), entity.get("context", ""), captured_at, captured_at),
            )
        row = conn.execute("SELECT * FROM entities WHERE user_id = ? AND id = ?", (user_id, entity_id)).fetchone()
        return {
            "id": row["id"],
            "user_id": user_id,
            "kind": row["kind"],
            "name": row["name"],
            "aliases": json.loads(row["aliases_json"] or "[]"),
            "context": row["context"],
            "first_seen": row["first_seen"],
            "last_seen": row["last_seen"],
        }

    def _edge(self, conn, user_id: str, source_id: str, target_id: str, kind: str, evidence_id: str, created_at: str, weight: float = 1.0) -> dict[str, Any]:
        edge_id = stable_id("edge_", user_id + source_id + target_id + kind + evidence_id)
        conn.execute(
            "INSERT OR REPLACE INTO graph_edges (id, user_id, source_id, target_id, kind, weight, evidence_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (edge_id, user_id, source_id, target_id, kind, weight, evidence_id, created_at),
        )
        return {"id": edge_id, "user_id": user_id, "source_id": source_id, "target_id": target_id, "kind": kind, "weight": weight, "evidence_id": evidence_id, "created_at": created_at}

    def _event(self, conn, user_id: str, object_id: str, object_type: str, event_type: str, metadata: dict[str, Any]) -> dict[str, Any]:
        created_at = now_iso()
        event_id = stable_id("evt_", user_id + object_id + object_type + event_type + created_at)
        conn.execute(
            "INSERT OR REPLACE INTO memory_events(id, user_id, object_id, object_type, event_type, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (event_id, user_id, object_id, object_type, event_type, json.dumps(metadata), created_at),
        )
        event = {
            "id": event_id,
            "user_id": user_id,
            "object_id": object_id,
            "object_type": object_type,
            "event_type": event_type,
            "metadata": metadata,
            "created_at": created_at,
        }
        self.vault.append_event(event)
        return event

    def _capture_from_row(self, row) -> dict[str, Any]:
        keys = set(row.keys())
        return {
            "id": row["id"],
            "source": row["source"],
            "source_url": row["source_url"],
            "title": row["title"],
            "summary": row["summary"],
            "review_status": row["review_status"],
            "approved_at": row["approved_at"],
            "archived_at": row["archived_at"],
            "captured_at": row["captured_at"],
            "memory_count": row["memory_count"] if "memory_count" in keys else None,
            "task_count": row["task_count"] if "task_count" in keys else None,
        }

    def _memory_from_row(self, row) -> dict[str, Any]:
        keys = set(row.keys())
        kind = row["kind"]
        return {
            "id": row["id"],
            "kind": kind,
            "layer": memory_layer(kind, row["layer"] if "layer" in keys else None),
            "content": row["content"],
            "summary": row["summary"],
            "source": row["source"],
            "source_url": row["source_url"],
            "confidence": row["confidence"],
            "importance": row["importance"],
            "status": row["status"],
            "topics": json.loads(row["topics_json"] or "[]"),
            "entity_ids": json.loads(row["entity_ids_json"] or "[]"),
            "occurred_at": row["occurred_at"],
            "captured_at": row["captured_at"],
            "raw_excerpt": row["raw_excerpt"],
        }

    def _task_from_row(self, row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "kind": row["kind"],
            "content": row["content"],
            "status": row["status"],
            "importance": row["importance"],
            "topics": json.loads(row["topics_json"] or "[]"),
            "entity_ids": json.loads(row["entity_ids_json"] or "[]"),
            "captured_at": row["captured_at"],
        }

    def _entity_from_row(self, row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "kind": row["kind"],
            "name": row["name"],
            "aliases": json.loads(row["aliases_json"] or "[]"),
            "context": row["context"],
            "first_seen": row["first_seen"],
            "last_seen": row["last_seen"],
        }

    def _memories_by_kind(self, user_id: str, kind: str, limit: int) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            filters, params = self._memory_filters(user_id, user_settings, alias="m", kind=kind)
            where = " AND ".join(filters)
            rows = conn.execute(
                f"""
                SELECT *
                FROM memories m
                WHERE {where}
                ORDER BY m.importance DESC, m.captured_at DESC
                LIMIT ?
                """,
                [*params, limit],
            ).fetchall()
        return [self._memory_from_row(row) for row in rows]

    def _memories_by_layer(self, user_id: str, layer: str, limit: int, *, include_pending: bool = False) -> list[dict[str, Any]]:
        with connect(self.db_path) as conn:
            user_settings = self._settings(conn, user_id)
            if not include_pending:
                user_settings = {**user_settings, "allow_pending_in_context": False}
            filters, params = self._memory_filters(user_id, user_settings, alias="m", layer=layer)
            where = " AND ".join(filters)
            rows = conn.execute(
                f"""
                SELECT *
                FROM memories m
                WHERE {where}
                ORDER BY m.importance DESC, m.captured_at DESC
                LIMIT ?
                """,
                [*params, limit],
            ).fetchall()
        return [self._memory_from_row(row) for row in rows]

    def _recommended_actions(
        self,
        *,
        pending_count: int,
        open_task_count: int,
        captured_today: int,
        top_topics: list[dict[str, Any]],
        recent_decisions: list[dict[str, Any]],
    ) -> list[str]:
        actions: list[str] = []
        if pending_count:
            actions.append(f"Review {pending_count} pending capture{'s' if pending_count != 1 else ''}.")
        if open_task_count:
            actions.append(f"Clear or update {open_task_count} open loop{'s' if open_task_count != 1 else ''}.")
        if captured_today == 0:
            actions.append("Add one useful source today so your personal model has fresh signal.")
        if top_topics:
            actions.append(f"Use Cortex's #{top_topics[0]['topic']} memory before your next AI session.")
        if not recent_decisions:
            actions.append("Capture the next decision explicitly so it is easy to retrieve later.")
        return actions[:5]

    def _fts_query(self, query: str) -> str:
        tokens = [token for token in query.lower().replace("'", "").split() if token]
        normalized: list[str] = []
        for token in tokens:
            clean = "".join(ch for ch in token if ch.isalnum() or ch == "_").strip("_")
            if clean:
                normalized.append(clean + "*")
        return " ".join(normalized)
